drop database if exists twitter_clone;
create database twitter_clone;
use twitter_clone;


CREATE TABLE usuarios (
  usuario varchar(50) ,
  email varchar (50) ,
  senha varchar(20) 
  );