<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>
	</title>
</head>
<body>
	<form action="cadastrar2.php" method="post">
		<p>nome: <input type="text" name="nome" /></p>
		<p>email: <input type="email" name="email" /></p>
		<p>senha: <input type="password" name="senha" /></p>
		<p><button type="submit">Cadastrar</button></p>
	</form>
</body>
</html>