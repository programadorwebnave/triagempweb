<?php  
	$email = $_POST['email'];
	$senha = $_POST['senha'];

	include "banco.php";

	$query = "select * from usuario where email = '$email' and senha = '$senha' limit 1";

	$consulta = mysqli_query($con, $query);

	$total = mysqli_num_rows($consulta);

	if($total == 0){
		header("Refresh: 5, entrar.php");
		echo "E-mail ou senha inválida";
	}else{
		while($u = mysqli_fetch_array($consulta)){
			$nome = $u['nome'];
		}

		setcookie("nome", $nome, time()+600);
		setcookie("email", $email, time()+600);
		
		if(empty($_GET['idproduto'])){
			header("Location: index.php");
		}else{
			$idproduto = $_GET['idproduto'];
			header("Location: carrinho.php?idproduto=$idproduto");
		}


	}

?>