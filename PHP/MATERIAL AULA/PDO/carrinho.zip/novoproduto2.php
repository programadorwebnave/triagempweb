<?php 
	$titulo = $_POST['titulo'];
	$descricao = $_POST['descricao'];
	$valor = $_POST['valor'];

	include "banco.php";

	$q = mysqli_query($con, "insert into produto(titulo, descricao, valor) values('$titulo', '$descricao', $valor)");

	include "upload.php";
	echo "<h1>$titulo</h1><p>Descrição: $descricao</p>";
?>


