<?php 
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$senha = $_POST['senha'];

	include "banco.php";

	mysqli_query($con, "insert into usuario(nome, email, senha) values ('$nome', '$email', '$senha')");

	setcookie("nome", $nome, time()+600);
	setcookie("email", $email, time()+600);

	header("Location: index.php");

?>