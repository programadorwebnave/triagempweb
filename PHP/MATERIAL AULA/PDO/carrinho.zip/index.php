<?php 
	
	if(empty($_COOKIE['email'])){
		echo "<a href='entrar.php'>Entrar</a> - <a href='cadastrar.php'>Cadastrar</a>";
	}else{
		$nome = $_COOKIE['nome'];
		echo "$nome - <a href='sair.php'>Sair</a>";
	}

	include "banco.php";

	$query = "select * from produto";

	$c = mysqli_query($con, $query);

	while($p = mysqli_fetch_array($c)){
		$idproduto = $p['idproduto'];
		$titulo = $p['titulo'];
		$descricao = $p['descricao'];
		$valor = $p['valor'];
		$img = $p['img'];

		echo "<h1>$titulo</h1><img src='imgproduto/$img' width='100px'>
		<p>Descrição: $descricao</p><p>R$ $valor</p><a href='carrinho.php?idproduto=$idproduto'>Adicionar ao carrinho</a><hr>";

	}

?>