<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php 

		// se esta página vier do carrinho, passará o id do produto, caso contrário, apenas irá fazer a conexão
		if(isset($_GET['idproduto'])){
			$idproduto = $_GET['idproduto'];
			$link = "entrar2.php?idproduto=$idproduto";
		}else{
			$link = "entrar2.php";
		}

	?>
	<form action="<?php echo $link; ?>" method="post">
		<p>email <input type="email" name="email"></p>
		<p>senha <input type="senha" name="senha"></p>
		<button type="submit">Entrar</button>
	</form>
</body>
</html>