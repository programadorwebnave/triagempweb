<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Novo Produto</title>
</head>
<body>
	<form action="novoproduto2.php" method="post" enctype="multipart/form-data">
		<div>
			<label for="titulo">Título do Anúncio</label>
			<input type="text" name="titulo" id="titulo" />
		</div>
		<div>
			<label for="descricao">Descrição do Anúncio</label>
			<input type="text" name="descricao" id="descricao" />
		</div>
		<div>
			<label for="valor">Valor</label>
			<input type="text" name="valor" id="valor" />
		</div>
		<div>
			<label for="foto">Foto</label>
			<input type="file" name="arquivo" id="foto" accept="image/jpeg, image/png" />
		</div>

		<button type="submit">Cadastrar</button>

		<p><a href="index.php">Página Inicial</a></p>
	</form>
</body>
</html>