<!DOCTYPE html>
<?php 
session_start();
include "validacao/functions.php";
if(isset($_SESSION['usuariofuncionario'])){
    $fun = selectfuncionarioid($_SESSION['usuariofuncionario']);
}
else{
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
}
?>
<?php
function searchbancovagas (){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM bancovagas";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($result)){
        $grupo[] = $row;
    }
    return $grupo;
}
    
     function selectpg($a, $b){
    $conn = conect();
    $sql = "SELECT * FROM bancovagas WHERE cargo = '$a' AND regiao = '$b';";
    $grupo = array();
    $push = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($push)){
        $grupo[] = $row;
    }
    return ($grupo);
}
     ?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagina Incial - HotelJob</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/styles.css" type="text/css" !important>
      <link rel="stylesheet" href="../css/menulateral.css" !important>
        <script src="../js/responsive-nav.js"></script>

      <link rel="icon" href="../img/logo-edit.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="body">
        <!-- INICIO DO MENU DE NAVEGAÇÃO -->

      <div role="navigation" id="foo" class="nav-collapse">
        <li><h2  style="color: #fff"><?=$fun['nome']?></h2></li>
      <ul>
         
        <li><a href="paginainicial.php" style="color: #fff">Banco de Vagas</a></li>
        <li><a href="editarperfis/editarfuncionario.php" style="color: #fff">Editar Perfil</a></li>
                  <li><a href="propostas.php" style="color: #fff">Propostas</a></li>

        <li><a href="validacao/sair.php" style="color: #fff">Sair</a></li>
          </ul>
    </div>

    <div role="main" class="main">
      <a href="#nav" class="nav-toggle">Menu</a>
        
        
                 <div class="container-fluid">
      <div class="logo_banco col-md-5">
        <img src="../img/logo-edit.png" class="img-responsive">
        </div>
      <div class="row">
          <div class="col-xs-10 col-md-5 titulovagas">
          <h1>Banco de Vagas</h1><hr>
              <h2>Filtrar Vagas</h2>
          </div>
                     </div>
          <div class="container-fluid">
              <div class="row">
            <div class="col-xs-10 col-sm-10">
                              <form class="form-group" method="post" action="#">
                      <div class="col-xs-12">
                          <div class="row">
                  <div class="col-xs-6 col-sm-5 col-lg-3">
                  <label>Cargo</label>
            <select id="cargo" name="cargo" class="form-control">
		      <option value="Garcon">Garçon</option>
		      <option value="Steward">Steward</option>
		      <option value="Cumin">Cumin</option>
		      <option value="Camareira">Camareira</option>
              <option value="Chefe de Andar">Chefe de Andar</option>
		      <option value="Governanta">Governanta</option>
		      <option value="Recepcionista">Recepcionista</option>
		      <option value="Mensageiro">Mensageiro</option>
              <option value="Auxiliar de Manutenção">Auxiliar de Manutenção</option>
		      <option value="Eletricista">Eletricista</option>
		      <option value="Bombeiro">Bombeiro</option>
		      <option value="Marceneiro">Marceneiro</option>
		      <option value="Rede e Telefonia">Rede e Telefonia</option>
              <option value="Pintor">Pintor</option>
		      <option value="Pedreiro">Pedreiro</option>
	</select></div>
                  <div class="col-xs-6 col-sm-5 col-lg-3">
                <!-- [[[[[[[        CAMPO ESTADO        ]]]]]]]-->
<!-- [[[[[[[        CAMPO Região       ]]]]]]]-->
	<label for="formulario_estado">Região</label>
<select name="regiao" class="form-control">
	<option value="Zona Norte">Zona Norte</option>
    <option value="Zona Sul">Zona Sul</option>
    <option value="Zona Leste">Zona Leste</option>
    <option value="Zona Oeste">Zona Oeste</option>
</select><br></div>
                  <input type="hidden" name="acao" value="selectfilterempresa">
                <div class="col-xs-2 margem col-sm-2">
            <input type="submit" class="btn btn-default butao" value="Pesquisar" class="form-group">
                  </div>
                          </div></div></form>
                  

    
              </div></div></div></div>  
     
              
              
          
          
          
          
          
          
          
               <div class="container-fluid">
            <?php 
   
if ((empty($_POST['cargo'])) && (empty($_POST['regiao']))){
    $grupo = searchbancovagas();
    foreach ($grupo as $row){
        echo "
        <div class='col-xs-12 box_funcionarios'>
        
        <div class='informacao pull-left'>
        <h1>".$row['titulovaga']."</h1>
        <h2><strong>".$row['nomefachada']."</strong></h2>
        
        <h4><span class='fa fa-cog' style='color:#000'></span>&nbsp;&nbsp;".$row['descricao']."&nbsp;&nbsp;<span class='fa fa-graduation-cap' style='color:#000'></span>&nbsp;&nbsp;".$row['experiencia']."&nbsp;&nbsp;<span class='fa fa-map-marker' style='color:#000'></span> ".$row['cidade']." ". $row['regiao']."&nbsp;&nbsp; <span class='fa fa-money' style='color:#000'></span>&nbsp;&nbsp;".$row['salario']."<br>
        
        <form method='post' action='validacao/inserircandidato.php'>
        <input type='hidden' name='cpf' value='".$fun['cpf']."'>
        <input type='hidden' name='cnpj' value='".$row['CNPJ']."'>
        <input type='hidden' name='acao' value='inserircandidato'>
         <input type='submit' class='btn btn-default'  style='width: 40%; border: none; margin: 10px 0 10px 0; background: rgb(183,132,9);float:left; color: #fff' value='Candidatar-se'>
        
        </form>
      
        
        </div>
</div>
        ";
    }    
}?>

           
 <?php 
           
           
if((isset($_POST['cargo'])) && (isset($_POST['regiao']))){
    $row = selectpg($_POST['cargo'], $_POST['regiao']);
    if (empty($row)){
        echo "<div class='alert alert-warning'>
        <strong>Desculpe!</strong> Não foi encontrado nenhum funcionario correspondente à pesquisa.
        </div>";
    }
    else{
        
        $grupo = selectpg($_POST['cargo'], $_POST['regiao']);
    foreach ($grupo as $row){
        echo "
        <div class='col-xs-12 box_funcionarios'>
        
        <div class='informacao pull-left'>
        <h1>".$row['titulovaga']."</h1>
        <h2><strong>".$row['nomefachada']."</strong></h2>
        
        <h4><span class='fa fa-cog' style='color:#000'></span>&nbsp;&nbsp;".$row['descricao']."&nbsp;&nbsp;<span class='fa fa-graduation-cap' style='color:#000'></span>&nbsp;&nbsp;".$row['experiencia']."&nbsp;&nbsp;<span class='fa fa-map-marker' style='color:#000'></span> ".$row['cidade']." ". $row['regiao']."&nbsp;&nbsp; <span class='fa fa-money' style='color:#000'></span>&nbsp;&nbsp;".$row['salario']."<br>
        
        <form method='post' action='validacao/inserircandidato.php'>
        <input type='hidden' name='cpf' value='".$fun['cpf']."'>
        <input type='hidden' name='cnpj' value='".$row['CNPJ']."'>
        <input type='hidden' name='acao' value='inserircandidato'>
         <input type='submit' class='btn btn-default'  style='width: 40%; border: none; margin: 10px 0 10px 0; background: rgb(183,132,9);float:left; color: #fff' value='Candidatar-se'>
        
        </form>
      
        
        </div>
        </div>
        ";
    }  
    }
} 

                    
?>
    
    </div>

      <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
      
      
      
      </div>
      
    </body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script type="text/javascript">
	  
  $(document).ready(function() {
        
	/*Menu-toggle*/
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("active");
    });

    /*Scroll Spy*/
    $('body').scrollspy({ target: '#spy', offset:80});

    /*Smooth link animation*/
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
        
        });
      </script>
       <script>
      var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
    </script>
</html>