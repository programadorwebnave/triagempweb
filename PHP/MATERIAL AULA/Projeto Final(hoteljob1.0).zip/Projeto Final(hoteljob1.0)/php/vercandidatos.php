<!DOCTYPE html>
<?php
session_start();
include "validacao/functions.php";
      if(isset($_SESSION['usuarioempresa'])){
          $emp = selectIDempresa($_SESSION['usuarioempresa']);
      }
?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagina Incial - HotelJob</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/styles.css" type="text/css" !important>
        <script src="../js/responsive-nav.js"></script>
      <style>span{color: #000}</style>
      <link rel="icon" href="../img/logo-edit.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="body">
        <!-- INICIO DO MENU DE NAVEGAÇÃO -->

      <div role="navigation" id="foo" class="nav-collapse">
        <li><h2  style="color: #fff"><?=$emp['nomefachada']?></h2></li>
      <ul>
         
        <li><a href="../php/paginainicialempresa.php" style="color: #fff">Banco de Funcionarios</a></li>
        <li><a href="editarperfis/editarempresa.php" style="color: #fff">Editar Perfil</a></li>
        <li><a href="adicionarvaga.php" style="color: #fff">Adicionar Vagas</a></li>
        <li> <a href="gerenciarvagas.php" style="color: #fff">Gerenciar Vagas</a></li>
        <li><a href="vercandidatos.php" style="color: #fff">Ver Candidatos</a></li>
        <li><a href="validacao/sair.php" style="color: #fff">Sair</a></li>
          </ul>
    </div>

    <div role="main" class="main">
      <a href="#nav" class="nav-toggle">Menu</a>
         
         <div class="container-fluid">
      <div class="logo_banco col-md-5">
        <img src="../img/logo-edit.png" class="img-responsive">
        </div>
      <div class="row">
          <div class="col-xs-12 col-md-5 titulovagas">
          <h1>Banco de Candidatos</h1><hr>
              <h2>Gerenciar Candidatos</h2>
          </div>
          
          <div class="container-fluid">   
          <div class="col-xs-12">
      
    <?php
    $row = selectcandidatos($emp['cnpj']);
    if (empty($row)){
        echo "<div class='alert alert-info' role='alert'><strong>Nenhum Candidato no Momento</strong></div>";
    }
           else{
               foreach($row as $grupo){
                   echo "
                   
        <div class='col-xs-12 box_funcionarios'>
        
        <div class='informacao pull-left'>
        <h1>".$grupo['cargo']."</h1>
        <h2><strong>".$grupo['nome']."</strong></h2>
        
        <h4><span class='fa fa-user' style='color:#000'></span>&nbsp;&nbsp;".$grupo['sexo']."&nbsp;&nbsp;<span class='fa fa-map-marker' style='color:#000'></span>&nbsp;&nbsp;".$grupo['endereco']." ".$grupo['regiao']."&nbsp;&nbsp; <span class='fa fa-phone' style='color:#000'></span>&nbsp;&nbsp;".$grupo['telefone']."&nbsp;&nbsp;&nbsp;&nbsp;<span class='fa fa-envelope'></span>&nbsp;&nbsp;".$grupo['email']."<br>
        
       <form method='post' action='validacao/inserircandidato.php'>
<input type='hidden' name='id' value='".$grupo['id']."'>
<input type='hidden' name='acao' value='deletarcandidato'>
<input type='submit' style='background:rgb(183,132,9)' class='btn btn-primary btn_visitar' value='Deletar'></form>  
        
        </div>
</div>
                   
                ";
               }
               
           }
         
    ?>          
              
              
              
          </div>
          </div>
          
          
                <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
      </div>

      
      
      
      
      
      
      
<?php
    function selectcandidatos($cnpj){
    $conn = conect();
    $grupo = array();
    $sql = "SELECT * FROM candidatos WHERE cnpj = '$cnpj';";
    $push = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($push)){
        $grupo[] = $row;
    }
    return $grupo;
}
      
      
      ?>
      
    
    
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  
    <script>
    $(document).ready(function(){
    $("#money").inputmask('decimal', {
                'alias': 'numeric',
                'groupSeparator': ',',
                'autoGroup': true,
                'digits': 2,
                'radixPoint': ".",
                'digitsOptional': false,
                'allowMinus': false,
                'prefix': 'R$ ',
                'placeholder': ''
    });
</script>
    
    <script type="text/javascript">  
  $(document).ready(function() {
        
	/*Menu-toggle*/
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("active");
    });

    /*Scroll Spy*/
    $('body').scrollspy({ target: '#spy', offset:80});

    /*Smooth link animation*/
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
        
        });
      </script>
</html>
