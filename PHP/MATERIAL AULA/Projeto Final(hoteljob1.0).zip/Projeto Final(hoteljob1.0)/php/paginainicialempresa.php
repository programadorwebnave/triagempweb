<!DOCTYPE html>
<?php
session_start();
include "validacao/functions.php";
      if(isset($_SESSION['usuarioempresa'])){
          $emp = selectIDempresa($_SESSION['usuarioempresa']);
      }
?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagina Incial - HotelJob</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/styles.css" type="text/css" !important>
        <script src="../js/responsive-nav.js"></script>
      <style>span{color: #000}</style>
      <link rel="icon" href="../img/logo-edit.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <body id="body">
        <!-- INICIO DO MENU DE NAVEGAÇÃO -->

      <div role="navigation" id="foo" class="nav-collapse">
        <li><h2  style="color: #fff"><?=$emp['nomefachada']?></h2></li>
      <ul>
         
        <li><a href="paginainicialempresa.php" style="color: #fff">Banco de Funcionarios</a></li>
        <li><a href="editarperfis/editarempresa.php" style="color: #fff">Editar Perfil</a></li>
        <li><a href="adicionarvaga.php" style="color: #fff">Adicionar Vagas</a></li>
        <li> <a href="gerenciarvagas.php" style="color: #fff">Gerenciar Vagas</a></li>
        <li><a href="vercandidatos.php" style="color: #fff">Ver Candidatos</a></li>
        <li><a href="validacao/sair.php" style="color: #fff">Sair</a></li>
          </ul>
    </div>

    <div role="main" class="main">
      <a href="#nav" class="nav-toggle">Menu</a>
        
        
         <div class="container-fluid">
      <div class="logo_banco col-md-5">
        <img src="../img/logo-edit.png" class="img-responsive">
        </div>
      <div class="row">
          <div class="col-xs-10 col-md-5 titulovagas">
          <h1>Banco de Funcionarios</h1><hr>
              <h2>Filtrar Funcionarios</h2>
          </div>
             </div>
          <div class="container-fluid">
              <div class="row">
            <div class="col-xs-10 col-sm-12s">
                        <form class="form-group" method="post" action="#">
            <div class="col-xs-6 col-sm-5 col-lg-3">
                <label>Cargo</label>
            <select id="cargo" name="cargo" class="form-control">
		      <option value="Garcon">Garçon</option>
		      <option value="Steward">Steward</option>
		      <option value="Cumin">Cumin</option>
		      <option value="Camareira">Camareira</option>
              <option value="Chefe de Andar">Chefe de Andar</option>
		      <option value="Governanta">Governanta</option>
		      <option value="Recepcionista">Recepcionista</option>
		      <option value="Mensageiro">Mensageiro</option>
              <option value="Auxiliar de Manutenção">Auxiliar de Manutenção</option>
		      <option value="Eletricista">Eletricista</option>
		      <option value="Bombeiro">Bombeiro</option>
		      <option value="Marceneiro">Marceneiro</option>
		      <option value="Rede e Telefonia">Rede e Telefonia</option>
              <option value="Pintor">Pintor</option>
		      <option value="Pedreiro">Pedreiro</option>
	</select>
                </div>
                <!-- [[[[[[[        CAMPO ESTADO        ]]]]]]]-->
                <div class="col-xs-6 col-sm-5 col-lg-3">
	<!-- [[[[[[[        CAMPO Regiao        ]]]]]]]-->
	<label for="formulario_estado">Região</label>
<select name="regiao" class="form-control">
	<option value="Zona Norte">Zona Norte</option>
    <option value="Zona Sul">Zona Sul</option>
    <option value="Zona Leste">Zona Leste</option>
    <option value="Zona Oeste">Zona Oeste</option>
</select><br>
     <input type="hidden" name="acao" value="selectfilterempresa">
                </div>
                <div class="col-xs-2 col-sm-2 margem">
            <input type="submit" class="btn btn-default  butao" value="Pesquisar" class="form-group">
                    </div>
                </form>

                  

    
              </div></div></div></div>  
     
        
        
        
        
        
      <div class="container-fluid">
            <?php 
   
if ((empty($_POST['cargo'])) && (empty($_POST['regiao']))){
    $grupo = selectfuncionarios();
    foreach ($grupo as $row){
        echo "
        
        <div class='col-xs-12 box_funcionarios'>
        
        <div class='informacao pull-left'>
        <h1>".$row['cargo']."</h1>
        <h2><strong>".$row['nome']."</strong></h2>
        
        <h4><span class='fa fa-user' style='color:#000'></span>&nbsp;&nbsp;".$row['sexo']."&nbsp;&nbsp;<span class='fa fa-map-marker' style='color:#000'></span>&nbsp;&nbsp;".$row['endereco']." ".$row['regiao']."&nbsp;&nbsp; <span class='fa fa-phone' style='color:#000'></span>&nbsp;&nbsp;".$row['telefone']."&nbsp;&nbsp;&nbsp;&nbsp;<span class='fa fa-envelope'></span>&nbsp;&nbsp;".$row['email']."<br>
        
       <a href='#'><button type='button'  style='background:rgb(183,132,9)' class='btn btn-primary btn_visitar'>Ver Curriculo</button></a>    
       <form method='post' action='enviarproposta.php'>
       <input type='hidden' name='id' value='".$row['id']."'>
       <input type='submit' style='background:rgb(183,132,9)' class='btn btn-primary btn_visitar' value='Enviar Proposta'>
       </form>
        
        </div>
</div>
        
        
      ";
    }    
}?>

           
 <?php 
           
           
if((isset($_POST['cargo'])) && (isset($_POST['regiao']))){
    $row = selecta($_POST['cargo'], $_POST['regiao']);
    if (empty($row)){
        echo "<div class='alert alert-warning'>
        <strong>Desculpe!</strong> Não foi encontrado nenhum funcionario correspondente à pesquisa.
        </div>";
    }
    else{
        
        $grupo = selecta($_POST['cargo'], $_POST['regiao']);
    foreach ($grupo as $row){
        echo "
        <div class='col-xs-12 box_funcionarios'>
        
        <div class='informacao pull-left'>
        <h1>".$row['cargo']."</h1>
        <h2><strong>".$row['nome']."</strong></h2>
        
        <h4><span class='fa fa-user' style='color:#000'></span>&nbsp;&nbsp;".$row['sexo']."&nbsp;&nbsp;<span class='fa fa-map-marker' style='color:#000'></span>&nbsp;&nbsp;".$row['endereco']." ".$row['regiao']."&nbsp;&nbsp; <span class='fa fa-phone' style='color:#000'></span>&nbsp;&nbsp;".$row['telefone']."&nbsp;&nbsp;&nbsp;&nbsp;<span class='fa fa-envelope'></span>&nbsp;&nbsp;".$row['email']."<br>
        
       <a href='#'><button type='button'  style='background:rgb(183,132,9)' class='btn btn-primary btn_visitar'>Ver Curriculo</button></a>        
        
        </div>
</div>
        
        
      ";
    }  
    }
}                 
?>    </div>

        
        
        <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
        
        
        
      </div>
      </body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script type="text/javascript">
	  
  $(document).ready(function() {
        
	/*Menu-toggle*/
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("active");
    });

    /*Scroll Spy*/
    $('body').scrollspy({ target: '#spy', offset:80});

    /*Smooth link animation*/
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
        
        });
      </script>
       <script>
      var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
    </script>
</html>