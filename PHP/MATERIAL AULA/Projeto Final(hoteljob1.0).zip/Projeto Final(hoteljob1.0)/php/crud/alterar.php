<!DOCTYPE html>
<?php session_start() ?>
<html lang="pt-br">
<head>
	<title>Cadastrar</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="../../css/pgcadastro.css" !important>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../../js/jquery-1.2.6.pack.js"></script>
<script type="text/javascript" src="../../js/jquery.maskedinput-1.1.4.pack.js"></script>
    <style>span{color: #f00}</style>
</head>
<body>
<?php include "../validacao/functions.php"; $l = selectID($_POST['id']); ?>
          <!-- Div que vai comportar o modal -->
    
          <div class="col-xs-12 col-sm-8 col-sm-push-2 col-md-12 col-md-push-0 moddal">
              <!-- Este é o video de background -->
          <video autoplay loop poster="images/torres.jpg" class="bg_video">
 <source src="../../video/city-night.mp4" type="video/mp4">
</video> 

<div class="col-xs-10 col-xs-push-1">
<form class="form-group" action="../validacao/functions.php" method="POST" enctype="multipart/form-data" accept-charset="utf-8">

<div class="modal-header"><!-- Inicio do cabecalho do modal -->

    <h1 class="modal-title">Alterar Cadastro</h1>
          </div><br>
<div class="modal-body">
    
    <div class="col-md-6">
<!-- [[[[[[     CAMPO NOME      ]]]]]]-->
	<label class="col-form-label">Nome</label>
	<input class="form-control" type="text" placeholder="Digite seu nome completo" name="nome" value='<?=$l['nome']?>'
<?php
    if(isset($_SESSION["v_nome"])){
        echo "value= '".$_SESSION["v_nome"]."'";
        unset($_SESSION["v_nome"]);
    }?>>
<?php 
    if (isset($_SESSION["nome_vazio"])){
        echo "<span>".$_SESSION["nome_vazio"]."</span>";
        unset($_SESSION["nome_vazio"]);
}?><br>
    
<!--[[[[[[[     CAMPO EMAIL     ]]]]]]]-->
    <label>E-mail</label>
	<input class="form-control" type="email" placeholder="Este Campo não pode ser alterado" disabled>
<br>
    
	<div class="form-group">
<!-- [[[[[[[        CAMPO DATA      ]]]]]]]-->
	<label for="formulario_idade">Data de Nascimento</label>
	<input class="form-control" type="text" name="data" placeholder="00/00/0000" OnKeyUp="mascaraData(this);" maxlength="10" value="<?=$l['data']?>"
<?php
    if(isset($_SESSION["v_data"])){
        echo "value= '".$_SESSION["v_data"]."'";
        unset($_SESSION["v_data"]);
    }?>>
<?php 
    if (isset($_SESSION["data_vazio"])){
        echo "<span>".$_SESSION["data_vazio"]."</span>";
        unset($_SESSION["data_vazio"]);
}?>
	</div>

    <!-- [[[[[[     CAMPO CARGO      ]]]]]]-->
	<label for="cargo">Cargo</label>
	<select id="cargo" name="cargo" class="form-control">
		<option value="Garçon">Garçon</option>
		<option value="Steward">Steward</option>
		<option value="Cumin">Cumin</option>
		<option value="Camareira">Camareira</option>
		<option value="Chefe de Andar">Chefe de Andar</option>
		<option value="Governanta">Governanta</option>
		<option value="Recepcionista">Recepcionista</option>
		<option value="Mensageiro">Mensageiro</option>
		<option value="Auxiliar de Manutenção">Auxiliar de Manutenção</option>
		<option value="Eletricista">Eletricista</option>
		<option value="Bombeiro">Bombeiro</option>
		<option value="Marceneiro">Marceneiro</option>
		<option value="Rede e Telefonia">Rede e Telefonia</option>
		<option value="Pintor">Pintor</option>
		<option value="Pedreiro">Pedreiro</option>
	</select><br>

    
<!--[[[[[[[[        CAMPO SEXO      ]]]]]]]]-->
	<label for="sexo">Sexo</label>
	<select id="sexo" class="form-control" name="sexo">

		<option value="Masculino">Masculino</option>
		<option value="Feminino">Feminino</option>

</select><br>
       
    <!-- [[[[[[[        CAMPO ENDEREÇO        ]]]]]]]-->
	<label>Endereço</label>
	<input class="form-control" type="text" placeholder="Digite seu Endereço" name="endereco" value="<?=$l['endereco']?>"
<?php
    if(isset($_SESSION["v_endereco"])){
        echo "value= '".$_SESSION["v_endereco"]."'";
        unset($_SESSION["v_endereco"]);
    }?>>
<?php 
    if (isset($_SESSION["endereco_vazio"])){
        echo "<span>".$_SESSION["endereco_vazio"]."</span>";
        unset($_SESSION["endereco_vazio"]);
}?><br>
    
<!-- [[[[[[[        CAMPO CIDADE        ]]]]]]]-->
	<label for="formulario_cidade">Cidade</label>
	<input class="form-control" type="text" placeholder="Digite sua cidade" name="cidade" value="<?=$l['cidade']?>"
<?php
    if(isset($_SESSION["v_cidade"])){
        echo "value= '".$_SESSION["v_cidade"]."'";
        unset($_SESSION["v_cidade"]);
    }?>>
<?php 
    if (isset($_SESSION["cidade_vazio"])){
        echo "<span>".$_SESSION["cidade_vazio"]."</span>";
        unset($_SESSION["cidade_vazio"]);
}?><br>
 </div>
    <div class="col-md-6">
    
<!-- [[[[[[[        CAMPO ESTADO        ]]]]]]]-->
	<label for="formulario_estado">Estado</label>
<select name="estado" class="form-control">
	<option value="AC">Acre</option>
	<option value="AL">Alagoas</option>
	<option value="AP">Amapá</option>
	<option value="AM">Amazonas</option>
	<option value="BA">Bahia</option>
	<option value="CE">Ceará</option>
	<option value="DF">Distrito Federal</option>
	<option value="ES">Espírito Santo</option>
	<option value="GO">Goiás</option>
	<option value="MA">Maranhão</option>
	<option value="MT">Mato Grosso</option>
	<option value="MS">Mato Grosso do Sul</option>
	<option value="MG">Minas Gerais</option>
	<option value="PA">Pará</option>
	<option value="PB">Paraíba</option>
	<option value="PR">Paraná</option>
	<option value="PE">Pernambuco</option>
	<option value="PI">Piauí</option>
	<option value="RJ">Rio de Janeiro</option>
	<option value="RN">Rio Grande do Norte</option>
	<option value="RS">Rio Grande do Sul</option>
	<option value="RO">Rondônia</option>
	<option value="RR">Roraima</option>
	<option value="SC">Santa Catarina</option>
	<option value="SP">São Paulo</option>
	<option value="SE">Sergipe</option>
	<option value="TO">Tocantins</option>
</select><br>
    
<!-- [[[[[[[        CAMPO CEP        ]]]]]]]-->
	<label for="formulario_cep">CEP</label>
	<input class="form-control" id="cep" type="text" placeholder="Digite seu cep" name="cep" value="<?=$l['cep']?>"
<?php
    if(isset($_SESSION["v_cep"])){
        echo "value= '".$_SESSION["v_cep"]."'";
        unset($_SESSION["v_cep"]);
    }?>>
<?php 
    if (isset($_SESSION["cep_vazio"])){
        echo "<span>".$_SESSION["cep_vazio"]."</span>";
        unset($_SESSION["cep_vazio"]);
}?><br>

<!-- [[[[[[[        CAMPO TELEFONE        ]]]]]]]-->
	<label for="formulario_telefone">Telefone</label>
     <input type="text" class="form-control" name="telefone" onkeyup="mascara( this, mtel );" maxlength="15" value="<?=$l['telefone']?>"
placeholder="(11) 11111-1111"
<?php
    if(isset($_SESSION["v_telefone"])){
        echo "value= '".$_SESSION["v_telefone"]."'";
        unset($_SESSION["v_telefone"]);
    }?>>
<?php 
    if (isset($_SESSION["telefone_vazio"])){
        echo "<span>".$_SESSION["telefone_vazio"]."</span>";
        unset($_SESSION["telefone_vazio"]);
}?><br>
    <!-- [[[[[[[        CAMPO RG        ]]]]]]]-->
	<label for="formulario_identidade">RG</label>
	<input class="form-control" type="email" placeholder="Este Campo não pode ser alterado" disabled>
    <br>

<!-- [[[[[[[        CAMPO CPF        ]]]]]]]-->
	<label for="formulario_cpf">CPF</label>
<input class="form-control" type="email" placeholder="Este Campo não pode ser alterado" disabled> <br>
	
    
<!-- [[[[[[[        CAMPO Senha         ]]]]]]]-->
	<label for="formulario_eleitor">Senha</label>
	<input class="form-control" type="password" name="senha">
<?php 
    if (isset($_SESSION["senha_vazio"])){
        echo "<span>".$_SESSION["senha_vazio"]."</span>";
        unset($_SESSION["senha_vazio"]);
}if (isset($_SESSION["senha_erro"])){
        echo "<span>".$_SESSION["senha_erro"]."</span>";
        unset($_SESSION["senha_erro"]);
}?><br>
	

<!-- [[[[[[[        CAMPO Confirmar Senha        ]]]]]]]-->
	<label for="formulario_cart_trab">Confirmar Senha</label>
	<input class="form-control" type="password" name="c_senha">
<?php 
    if (isset($_SESSION["senha_vazio2"])){
        echo "<span>".$_SESSION["senha_vazio2"]."</span>";
        unset($_SESSION["senha_vazio2"]);}
    
    if (isset($_SESSION["senha_erro2"])){
        echo "<span>".$_SESSION["senha_erro2"]."</span>";
        unset($_SESSION["senha_erro2"]);
}?>
   
<br>    
    <input type="hidden" class="btn btn-default" name="acao" value="alterar">
    <input type="hidden" name="id" value="<?=$l['id']?>">
	<input type="submit" class="btn btn-default" name="cadastrar" value="Alterar Cadastro">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="../index.php">Voltar</a>
    </div>
</div>
    </form>
    <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
    <script language="JavaScript" type="text/javascript">
   function mascaraData(campoData){
              var data = campoData.value;
              if (data.length == 2){
                  data = data + '/';
                  document.forms[0].data.value = data;
      return true;              
              }
              if (data.length == 5){
                  data = data + '/';
                  document.forms[0].data.value = data;
                  return true;
              }
         }
        function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
}
</script>
<script type="text/javascript">
$(document).ready(function(){
	$("#cep").mask("99999-999");
     $('#rg').mask('99.999.999-9');
});
</script>
</body>
</html>