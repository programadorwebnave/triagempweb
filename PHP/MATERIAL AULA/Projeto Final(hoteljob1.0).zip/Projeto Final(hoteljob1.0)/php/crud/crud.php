<!DOCTYPE html>
<?php 
function conect(){
$conn = mysqli_connect('localhost','root','','cadastro') or die(mysqli_connect_error());
    return $conn;
}
function select (){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios ORDER BY nome";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($result)){
        $grupo[] = $row;
    }
    return $grupo;
}?>
<html lang="pt-br">
<head>
	<title>Cadastrar</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="../css/pgcadastro.css" !important>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    
    <h1>Banco de Cadastros</h1>
    &nbsp;<a href="../../index.php">Voltar</a>
 <table class="table table-responsive table-hover table-condensed">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>
                <th scope="col">Data</th>
                <th scope="col">Cargo</th>
                <th scope="col">Sexo</th>
                <th scope="col">Endereço</th>
                <th scope="col">Cidade</th>
                <th scope="col">Estado</th>
                <th scope="col">CEP</th>
                <th scope="col">Telefone</th>
                <th scope="col">RG</th>
                <th scope="col">CPF</th>
                <th scope="col">Senha</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $grupo = select();
                foreach($grupo as $pessoa){?>
                <tr>
                <td><?=$pessoa['id']?></td>
                <td><?=$pessoa['nome']?></td>
                <td><?=$pessoa['email']?></td>
                <td><?=$pessoa['data']?></td>
                <td><?=$pessoa['cargo']?></td>
                <td><?=$pessoa['sexo']?></td>
                <td><?=$pessoa['endereco']?></td>
                <td><?=$pessoa['cidade']?></td>
                <td><?=$pessoa['estado']?></td>
                <td><?=$pessoa['cep']?></td>
                <td><?=$pessoa['telefone']?></td>
                <td><?=$pessoa['rg']?></td>
                <td><?=$pessoa['cpf']?></td>
                <td><?=$pessoa['senha']?></td>
              
                <td><a href=''>
    <form method="post" action="alterar.php">
        <input type="hidden" name="id" value="<?=$pessoa['id']?>">
        <input type="submit" value="editar" name="editar">
         </form> </a></td>
                    
                <td><a href=''>
                    <form method="post" action="../validacao/functions.php">
                    <input type="hidden" name="id" value="<?=$pessoa['id']?>">
                    <input type="hidden" name="acao" value="excluir">
                        <input type="submit" value="excluir">
                    
                    </form>
                    </a></td>
                </tr>

                <?php } ?>
            
           
    </tbody>
        </table>
    
    
    
    
    
    

    </body>
</html>