<?php 
session_start();
if(isset($_SESSION['usuarioempresa'])){
    unset($_SESSION['usuarioempresa']);
    session_destroy();
    echo "<meta http-equiv='refresh' content='0;URL=../../index.php'>";
}
if (isset($_SESSION['usuariofuncionario'])){
    unset($_SESSION['usuariofuncionario']);
    session_destroy();
    echo "<meta http-equiv='refresh' content='0;URL=../../index.php'>";
}

?>