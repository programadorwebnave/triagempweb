<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Cadastrar</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="../css/pgcadastro.css" !important>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>span{color: #f00}</style>
</head>
<body>
<?php
function conect(){
$conn = mysqli_connect('mysql.hostinger.com.br','u478808797_admin','senacde1a6','u478808797_senac') or die(mysqli_connect_error());
    return $conn;
}
function inserir(){
$nome = $_POST["nome"];$email = $_POST["email"];$data = $_POST["data"];$cargo = $_POST["cargo"];$sexo = $_POST["sexo"];$endereco = $_POST["endereco"];$cidade = $_POST["cidade"];$regiao = $_POST["regiao"];$cep = $_POST["cep"];$telefone = $_POST["telefone"];$rg = $_POST["rg"];$cpf = $_POST["cpf"];$senha = $_POST["senha"]; 
    $conn = conect();
    $sql = "INSERT INTO funcionarios VALUES (default,'$nome','$email','$data','$cargo','$sexo','$endereco','$cidade','$regiao','$cep','$telefone','$rg','$cpf','$senha');";
    $push = mysqli_query($conn, $sql);
    if($push){
        echo"<div class='alert alert-success alert-dismissable'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Cadastro realizado com Sucesso</strong> Você será redirecionado em instantes para a pagina inicial.
</div>";
        echo"<META HTTP-EQUIV=REFRESH CONTENT = '3;URL=../../index.php'>";
    }
}
function alterar($id){
$nome = $_POST["nome"];$data = $_POST["data"];$cargo = $_POST["cargo"];$sexo = $_POST["sexo"];$endereco = $_POST["endereco"];$cidade = $_POST["cidade"];$estado = $_POST["estado"];$cep = $_POST["cep"];$telefone = $_POST["telefone"];$senha = $_POST["senha"];$c_senha = $_POST["c_senha"];
    $conn = conect();
    $sql = "UPDATE funcionarios SET nome = '$nome',data = '$data',cargo = '$cargo',sexo = '$sexo',endereco = '$endereco',cidade = '$cidade',estado = '$estado',cep = '$cep',telefone = '$telefone',senha = '$senha' WHERE id = '$id';";
    $push = mysqli_query($conn, $sql);
    if($push){
        echo"<div class='alert alert-success alert-dismissable'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Atualização Realizada com Sucesso!</strong> Você será redirecionado em instantes para a pagina inicial.
</div>";
        echo"<META HTTP-EQUIV=REFRESH CONTENT = '3;URL=../crud/crud.php'>";
    }
}
function selectID($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios WHERE id = ". $id;
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
function selectIDempresa($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM empresas WHERE id = ". $id;
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
function checkIFemail($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios WHERE email = '$id';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
function checkIFrg($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios WHERE rg = '$id';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
function checkIFcpf($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios WHERE cpf = '$id';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
    
if (isset($_POST['acao'])){
    if ($_POST['acao'] == "excluir"){
        $id = $_POST['id'];
    $conn = conect();
    $sql = "DELETE FROM funcionarios WHERE id = '$id';";
    $push = mysqli_query($conn, $sql);
    if($push){
        echo"<div class='alert alert-success alert-dismissable'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Atualização Realizada com Sucesso!</strong> Você será redirecionado em instantes para a pagina inicial.
</div>";
echo"<META HTTP-EQUIV=REFRESH CONTENT = '3;URL=../crud/crud.php'>";    }
    else{
        echo "deu bosta";
    }
}
    if ($_POST['acao'] == "alterar"){
    alterar($_POST['id']);
}
}
function checkIFemailempresa($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM empresas WHERE email = '$id';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
function checkIFcnpjempresa($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM empresas WHERE cnpj = '$id';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}

function selectempresaid($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM empresas WHERE id = ". $id;
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
    
function inserirempresa(){
$nome = $_POST["nome"];$nome_f = $_POST['nome_fachada']; $cnpj = $_POST['cnpj']; $email = $_POST["email"];$endereco = $_POST["endereco"];$cidade = $_POST["cidade"];$regiao = $_POST["regiao"];$cep = $_POST["cep"];$telefone = $_POST["telefone"];$senha = $_POST["senha"];$c_senha = $_POST["c_senha"];
    $conn = conect();
    $sql = "INSERT INTO empresas VALUES (default,'$nome','$nome_f','$cnpj','$email','$endereco','$cidade','$regiao','$cep','$telefone','$senha');";
    $push = mysqli_query($conn, $sql);
    if($push){
        
        echo"<div class='alert alert-success alert-dismissable'>
  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
  <strong>Cadastro realizado com Sucesso</strong> Você será redirecionado em instantes para a pagina inicial.
</div>";
        echo"<META HTTP-EQUIV=REFRESH CONTENT = '3;URL=../../index.php'>";
    }
}
function addvaga(){
    $emp = selectIDempresa($_POST['id']);
    $conn = conect();
    $titulovaga= $_POST['titulo_vaga']; $cargo = $_POST['cargo']; $descricao = $_POST['descricao']; $experiencia = $_POST['experiencia']; $salario = $_POST['salario'];
    $cnpj = $emp['cnpj']; $nomefachada = $emp['nomefachada']; $cidade = $emp['cidade']; $regiao = $emp['regiao'];
    
    $sql = "INSERT INTO bancovagas VALUES (default,'$titulovaga','$cargo','$descricao','$experiencia','$salario','$cnpj','$nomefachada','$cidade','$regiao');";
    $push = mysqli_query($conn, $sql);
    if($push){
        echo "<meta http-equiv=refresh content='0;URL=../paginainicialempresa.php'>";
    }
}
function deletarvaga($cnpj){
    echo $cnpj;
    $conn = conect();
    $sql = "DELETE FROM bancovagas WHERE id = '$cnpj';";
    $push = mysqli_query($conn, $sql);
    if ($push){
        echo "<meta http-equiv='refresh' content='0;URL=../gerenciarvagas.php'>";
    }
}
function entrarempresa(){
    if(isset($_SESSION['usuarioempresa'])){
        echo "<meta http-equiv='refresh' content='0;URL=../paginainicialempresa.php'>";
    }
    else{
        echo "<div class='alert alert-warning' role='alert'>
        <strong>Você precisa estar logado antes de acessar a página</strong>
        </div>";
        echo "<meta http-equiv='refresh' content='3;URL=../../index.php'>";
    }
}
function selectfuncionarioid($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios WHERE id = ". $id;
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}
    
    
function entrarfuncionario(){
    if(isset($_SESSION['usuariofuncionario'])){
        echo "<meta http-equiv='refresh' content='0;URL=../paginainicial.php'>";
    }
    else{
        echo "<div class='alert alert-warning' role='alert'>
        <strong>Você precisa estar logado antes de acessar a página</strong>
        </div>";
        echo "<meta http-equiv='refresh' content='3;URL=../../index.php'>";
    }
}

 function selectfuncionarios (){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($result)){
        $grupo[] = $row;
    }
    return $grupo;
}
function selecta ($a, $b){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios WHERE cargo = '$a' AND regiao = '$b';";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($result)){
        $grupo[] = $row;
    }
    return $grupo;
}
    

   function addproposta(){
    $emp = selectIDempresa($_POST['id']);
    $conn = conect();
    $titulovaga= $_POST['titulo_vaga']; $cargo = $_POST['cargo']; $descricao = $_POST['descricao']; $experiencia = $_POST['experiencia']; $salario = $_POST['salario']; $intrucoes = $_POST['intrucoes'];
    $cnpj = $emp['cnpj']; $nomefachada = $emp['nomefachada']; $cidade = $emp['cidade']; $regiao = $emp['regiao']; $cpf = $_POST['idfuncionario'];
    
    $sql = "INSERT INTO propostas VALUES (default,'$titulovaga','$cargo','$descricao','$experiencia','$salario','$cnpj','$nomefachada','$cidade','$regiao', '$intrucoes', '$cpf');";
    $push = mysqli_query($conn, $sql);
    if($push){
        echo "<div class='alert alert-success'>
  <strong>A Proposta Foi Enviada com Sucesso! </strong> Você retornará à pagina inicial
</div>";
        echo "<meta http-equiv=refresh content='3;URL=../paginainicialempresa.php'>";
    }
} 
    function deletarproposta(){
        $conn = conect();
        $id = $_POST['id'];
        $sql = "DELETE FROM propostas WHERE id = '$id';";
        $push = mysqli_query($conn, $sql);
        if ($push){
        echo "<div class='alert alert-success'>
  <strong>A Proposta Foi Deletada com Sucesso! </strong> Você retornará à pagina inicial
</div>";
        echo "<meta http-equiv=refresh content='3;URL=../paginainicial.php'>";
    }
    }
    
if (isset($_POST['acao'])){
    if($_POST['acao'] == 'inserirvaga'){
        addvaga();
    }
    if($_POST['acao'] == 'deletarvaga'){
        deletarvaga($_POST['id']);
    }
    if($_POST['acao'] == 'ckempresa'){
        entrarempresa();
    }
    if($_POST['acao'] == 'ckfuncionarios'){
        entrarfuncionario();
    }
    if($_POST['acao'] == 'enviarproposta'){
        addproposta();   
    }
     if($_POST['acao'] == 'deletarproposta'){
    deletarproposta();
}

}
    
 function selectfuncionariocpf($id){
    $grupo = array();
    $conn = conect();
    $sql = "SELECT * FROM funcionarios WHERE cpf = '$id';";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    return $row;
}   
    
    
    
    
    
    

    
    
    
    
    
    

?>
    </body>
</html>