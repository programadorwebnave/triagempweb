<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Cadastrar</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/style.css" !important>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>span{color: #f00}</style>
</head>
<?php
session_start();
include 'functions.php';
$url = '../pgcadastro.php';
$nome = $_POST["nome"];$email = $_POST["email"];$data = $_POST["data"];$cargo = $_POST["cargo"];$sexo = $_POST["sexo"];$endereco = $_POST["endereco"];$cidade = $_POST["cidade"];$regiao = $_POST["regiao"];$cep = $_POST["cep"];$telefone = $_POST["telefone"];$rg = $_POST["rg"];$cpf = $_POST["cpf"];$senha = $_POST["senha"];$c_senha = $_POST["c_senha"];
$check = 0;
    
if(empty($nome) || is_numeric($nome)){
    $_SESSION["nome_vazio"] = "Campo nome Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
if(isset($nome)){
    $_SESSION["v_nome"] = $_POST["nome"];
}
if(empty($email)){
    $_SESSION["email_vazio"] = "Campo Email não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
if(isset($email)){
    $ckemail = checkIFemail($email);
    if (isset($ckemail)){
        $_SESSION['email_ex'] = "O Email digitado já está sendo Ultilizado";
        echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
        $check++;
    }
}
else{
    $_SESSION["v_email"] = $email;
}
if(empty($data) || strlen($data) < 10){
    $_SESSION["data_vazio"] = "Campo data Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_data"] = $data;
}
if(empty($endereco)){
    $_SESSION["endereco_vazio"] = "Campo Cargo não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_endereco"] = $endereco;
}
if(empty($cidade)){
    $_SESSION["cidade_vazio"] = "Campo Endereço não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_cidade"] = $cidade;
}
if(empty($cep)) {
    $_SESSION["cep_vazio"] = "Campo CEP Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_cep"] = $cep;
}
if(empty($telefone)){
    $_SESSION["telefone_vazio"] = "Campo Telefone não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_telefone"] = $telefone;
}
if(empty($rg)|| strlen($rg) < 9){
    $_SESSION["rg_vazio"] = "O RG digitado é Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
if (isset($email)){
    $ck = checkIFrg($rg);
    if(isset($ck)){
        $_SESSION['rg_ex'] = "O RG digitado já está sendo ultilizazdo";
        echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
        $check++;
    }
}
else{
    $_SESSION["v_rg"] = $rg;
}
if(empty($cpf) || strlen($cpf) < 11){
    $_SESSION["cpf_vazio"] = "Campo CPF não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
if(isset($cpf)){
    $ck = checkIFcpf($cpf);
    if(isset($ck)){
        $_SESSION['cpf_ex'] = "O CPF digitado é Inválido";
        echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
        $check++;
    }
}
else{
    $_SESSION["v_cpf"] = $cpf;
}


if(empty($senha) || strlen($senha) < 6 ||empty($c_senha)){
    $_SESSION["senha_vazio"] = "Campo Senha Está Inválido<br>";
    $_SESSION["senha_vazio2"] = "Campo Senha Está Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else if($senha != $c_senha){
    $_SESSION["senha_erro"] = "As senhas não correspondem<br>";
    $_SESSION["senha_erro2"] = "As senhas não correspondem<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}

$acao = $_POST['acao'];
    
if ($check == 0 && $acao == "inserir"){
    inserir();
}
  