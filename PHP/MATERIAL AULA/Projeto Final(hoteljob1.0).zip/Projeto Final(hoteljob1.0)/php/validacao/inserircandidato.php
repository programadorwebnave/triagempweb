<?php
include 'functions.php';

if (isset($_POST['acao'])){
if($_POST['acao'] == 'inserircandidato'){
        $ck = selectcandidato($_POST['cpf'], $_POST['cnpj']);
        if (isset($ck)){
            echo "<div class='alert alert-danger' role='alert'><strong>Você já está concorrendo a uma vaga nessa empresa</strong>Espere o Processo Seletivo terminar!</div>";
            echo "<meta http-equiv='refresh' content='3;URL=../paginainicial.php'>";
        }
    else{
            $conn = conect();
            $cnpj = $_POST['cnpj'];
            $cand = selectfuncionariocpf($_POST['cpf']);
            $nome = $cand['nome'];
            $cargo = $cand['cargo'];
            $sexo = $cand['sexo'];
            $email = $cand['email'];
            $cidade = $cand['cidade'];
            $regiao = $cand['regiao'];
            $telefone = $cand['telefone'];
            $endereco = $cand['endereco'];
            $cpf = $cand['cpf'];
            $sql = "INSERT INTO candidatos VALUES (default, '$nome','$cargo','$sexo','$email','$cidade','$regiao','$endereco','$telefone','$cpf','$cnpj');";
            $push = mysqli_query($conn, $sql);
            if ($push){
                echo "<div class='alert alert-success' role='alert'><strong>Você agora está concorrendo a esta vaga!  </strong> Espere o Processo Seletivo terminar</div>";
                echo "<meta http-equiv='refresh' content='3;URL=../paginainicial.php'>";
            }
        }
}
}
function selectcandidato ($cpf, $cnpj){
    $conn = conect();
    $sql = "SELECT * FROM candidatos WHERE cpf = '$cpf' AND cnpj = '$cnpj';";
    $push = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($push);
    return $row;
}

function deletarcandidato ($id){
    $conn = conect();
    $sql = "DELETE FROM candidatos WHERE id = '$id';";
    $push = mysqli_query($conn, $sql);
    if ($push){
        echo "<div class='alert alert-success' role='alert'><strong>Vaga deletada com sucesso!         </strong> Você será redirecionado à pagina inicial</div>";
        echo "<meta http-equiv='refresh' content='3;URL=../vercandidatos.php'>";
    }
    else{echo "deu bosta";}
}

if(isset($_POST['acao'])){
    if($_POST['acao'] == 'deletarcandidato'){
        deletarcandidato($_POST['id']);
    }
}