<!DOCTYPE html>
<?php session_start();
include 'functions.php';
?>
<html lang="pt-br">
<head>
	<title>Cadastrar</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="../css/pgcadastro.css" !important>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>span{color: #f00}</style>
</head>
<body>
<?php
$email = $_POST["email"];
$senha = $_POST["senha"];
$sou = $_POST['sou'];
$conn = conect();
if ($email == "admin@admin.admin" && $senha == "1234" && $sou = "empresa"){
    echo "<meta http-equiv=refresh content='0;URL=../crud/crud.php'>";
}

else{
    if ($sou == "funcionario"){
    $conn = conect();
		$sql = "SELECT * FROM funcionarios WHERE email = '$email' && senha = '$senha';";
		$push = mysqli_query($conn, $sql);
		$resultado = mysqli_fetch_assoc($push);
		if(isset($resultado)){
            $_SESSION['usuariofuncionario'] = $resultado['id'];
            echo "<meta http-equiv=refresh content='0;URL=../../php/paginainicial.php'>";
}
else{echo'<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong>Erro!</strong> Login ou Senha estão incorretos
</div><meta http-equiv=refresh content="3;URL=../../index.php">';}
    }
}
    if ($sou == "empresa"){
        $conn = conect();
		$sql = "SELECT * FROM empresas WHERE email = '$email' && senha = '$senha';";
		$push = mysqli_query($conn, $sql);
		$resultado = mysqli_fetch_assoc($push);
		if(isset($resultado)){
            $_SESSION['usuarioempresa'] = $resultado['id'];
            echo "<meta http-equiv=refresh content='0;URL=../../php/paginainicialempresa.php'>";
}
else{echo'<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong>Erro!</strong> Login ou Senha estão incorretos
</div><meta http-equiv=refresh content="3;URL=../../index.php">';}
    }

    ?>
    </body>
</html>