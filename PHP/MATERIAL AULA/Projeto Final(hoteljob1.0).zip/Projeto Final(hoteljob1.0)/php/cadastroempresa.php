<!DOCTYPE html>
<?php session_start(); ?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HotelJob - Seu Proximo Emprego!</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/style.css" type="text/css" !important>
    <style>span{color: #f00}</style>
      <link rel="icon" href="img/logo-edit.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
<body class="cadastrar">
  <nav class="navbar navbar-default navbar-fixed-top menu">
      <div class="container-fluid">
          <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#barraBasica">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              </button>
                    <a class="navbar-brand" href="#"><img src="../img/hj2.png" class="img-responsive img_logo"></a>
          </div>
          <div class="collapse navbar-collapse menu_principal" id="barraBasica">
          <ul class="nav navbar-nav ul_lista">
              <li class="item_lista"><a href="../index.php" class="scroll" style="color:#fff">Home<span class="sr-only">(current)</span></a></li>
              <li class="item_lista"><a href="../index.php" style="color:#fff" class="scroll">Missão</a></li>
              <li class="item_lista"><a href="../index.php" class="scroll" style="color:#fff">Oportunidades</a></li>
              <li class="item_lista"><a style="color:#fff" href="#" data-toggle="modal" data-target="#login">Login</a></li>
              </ul>
              
          </div>
          </div>
      </nav>
    
          <div class="col-xs-12 col-sm-8 col-sm-push-2 col-md-12 col-md-push-0 moddal">
       

<div class="col-xs-10 col-xs-push-1">
<form class="form-group" action="../php/validacao/validaempresa.php" method="POST" enctype="multipart/form-data" accept-charset="utf-8">

<div class="modal-header"><!-- Inicio do cabecalho do modal -->

    <h1 class="modal-title">Insira os dados da empresa</h1>
        <div class="line"> </div>

          </div><br>
<div class="modal-body">
    
    <div class="col-md-6">
<!-- [[[[[[     CAMPO NOME      ]]]]]]-->
	<label class="col-form-label">Razão Social</label>
	<input class="form-control" type="text" placeholder="Nome Completo da Empresa" name="nome"
<?php
    if(isset($_SESSION["v_nome"])){
        echo "value= '".$_SESSION["v_nome"]."'";
        unset($_SESSION["v_nome"]);
    }?>>
<?php 
    if (isset($_SESSION["nome_vazio"])){
        echo "<span>".$_SESSION["nome_vazio"]."</span>";
        unset($_SESSION["nome_vazio"]);
}?><br>

<!--[[[[[[      CAMPO NOME DE FACHADA       ]]]]]]-->
<label>Nome de Fachada</label>
<input type="text" name="nome_fachada" placeholder="Nome Publicitario da Empresa" class="form-control" <?php
    if(isset($_SESSION["v_nomef"])){
        echo "value= '".$_SESSION["v_nomef"]."'";
        unset($_SESSION["v_nomef"]);
    }?>>
        
        <?php 
    if (isset($_SESSION["nomef_vazio"])){
        echo "<span>".$_SESSION["nomef_vazio"]."</span>";
        unset($_SESSION["nomef_vazio"]);
}?><br>
        
        
        
<!-- [[[[[[[        CAMPO CNPJ      ]]]]]]]-->
<label>CNPJ</label>
<input type="text" name="cnpj" class="form-control" placeholder="Digite o CNPJ da Empresa" maxlength="14"<?php
    if(isset($_SESSION["v_cnpj"])){
        echo "value= '".$_SESSION["v_cnpj"]."'";
        unset($_SESSION["v_cnpj"]);
    }?>>
<?php 
    if (isset($_SESSION["cnpj_vazio"])){
        echo "<span>".$_SESSION["cnpj_vazio"]."</span>";
        unset($_SESSION["cnpj_vazio"]);
}
        if(isset($_SESSION['cnpj_exist'])){
            echo "<span>".$_SESSION['cnpj_exist'].'</span><br>';
            unset($_SESSION['cnpj_exist']);
}
        ?>
        
        
        <br>
<!--[[[[[[[     CAMPO EMAIL     ]]]]]]]-->
    <label>E-mail</label>
	<input class="form-control" type="email" placeholder="Digite o Email da Empresa" name="email" 
<?php
    if(isset($_SESSION["v_email"])){
        echo "value= '".$_SESSION["v_email"]."'";
        unset($_SESSION["v_email"]);
    }?>>
<?php 
    if (isset($_SESSION["email_vazio"])){
        echo "<span>".$_SESSION["email_vazio"]."</span>";
        unset($_SESSION["email_vazio"]);
}
        if(isset($_SESSION['email_ex'])){
            echo "<span>".$_SESSION['email_ex'].'</span><br>';
            unset($_SESSION['email_ex']);
}
        
        ?>
    
	

    <br>
       
    <!-- [[[[[[[        CAMPO ENDEREÇO        ]]]]]]]-->
	<label>Endereço</label>
	<input class="form-control" type="text" placeholder="Digite seu Endereço" name="endereco" 
<?php
    if(isset($_SESSION["v_endereco"])){
        echo "value= '".$_SESSION["v_endereco"]."'";
        unset($_SESSION["v_endereco"]);
    }?>>
<?php 
    if (isset($_SESSION["endereco_vazio"])){
        echo "<span>".$_SESSION["endereco_vazio"]."</span>";
        unset($_SESSION["endereco_vazio"]);
}?><br>
    
<!-- [[[[[[[        CAMPO CIDADE        ]]]]]]]-->
	<label for="formulario_cidade">Cidade</label>
	<input class="form-control" type="text" placeholder="Digite sua cidade" name="cidade" 
<?php
    if(isset($_SESSION["v_cidade"])){
        echo "value= '".$_SESSION["v_cidade"]."'";
        unset($_SESSION["v_cidade"]);
    }?>>
<?php 
    if (isset($_SESSION["cidade_vazio"])){
        echo "<span>".$_SESSION["cidade_vazio"]."</span>";
        unset($_SESSION["cidade_vazio"]);
}?><br>
 </div>
    <div class="col-md-6">
    
<!-- [[[[[[[        CAMPO Regiao        ]]]]]]]-->
	<label for="formulario_estado">Região</label>
<select name="regiao" class="form-control">
	<option value="Zona Norte">Zona Norte</option>
    <option value="Zona Sul">Zona Sul</option>
    <option value="Zona Leste">Zona Leste</option>
    <option value="Zona Oeste">Zona Oeste</option>
</select><br>
    
<!-- [[[[[[[        CAMPO CEP        ]]]]]]]-->
	<label for="formulario_cep">CEP</label>
	<input class="form-control" id="cep" type="text" placeholder="Digite seu cep" name="cep" 
<?php
    if(isset($_SESSION["v_cep"])){
        echo "value= '".$_SESSION["v_cep"]."'";
        unset($_SESSION["v_cep"]);
    }?>>
<?php 
    if (isset($_SESSION["cep_vazio"])){
        echo "<span>".$_SESSION["cep_vazio"]."</span>";
        unset($_SESSION["cep_vazio"]);
}?><br>

<!-- [[[[[[[        CAMPO TELEFONE        ]]]]]]]-->
	<label for="formulario_telefone">Telefone</label>
     <input type="text" class="form-control" name="telefone" onkeyup="mascara( this, mtel );" maxlength="15" 
placeholder="(11) 11111-1111"
<?php
    if(isset($_SESSION["v_telefone"])){
        echo "value= '".$_SESSION["v_telefone"]."'";
        unset($_SESSION["v_telefone"]);
    }?>>
<?php 
    if (isset($_SESSION["telefone_vazio"])){
        echo "<span>".$_SESSION["telefone_vazio"]."</span>";
        unset($_SESSION["telefone_vazio"]);
}?><br>
    
<!-- [[[[[[[        CAMPO Senha         ]]]]]]]-->
	<label for="formulario_eleitor">Senha</label>
	<input class="form-control" type="password" name="senha">
<?php 
    if (isset($_SESSION["senha_vazio"])){
        echo "<span>".$_SESSION["senha_vazio"]."</span>";
        unset($_SESSION["senha_vazio"]);
}if (isset($_SESSION["senha_erro"])){
        echo "<span>".$_SESSION["senha_erro"]."</span>";
        unset($_SESSION["senha_erro"]);
}?><br>
	

<!-- [[[[[[[        CAMPO Confirmar Senha        ]]]]]]]-->
	<label for="formulario_cart_trab">Confirmar Senha</label>
	<input class="form-control" type="password" name="c_senha">
<?php 
    if (isset($_SESSION["senha_vazio2"])){
        echo "<span>".$_SESSION["senha_vazio2"]."</span>";
        unset($_SESSION["senha_vazio2"]);}
    
    if (isset($_SESSION["senha_erro2"])){
        echo "<span>".$_SESSION["senha_erro2"]."</span>";
        unset($_SESSION["senha_erro2"]);
}?>
   
<br>    
    <input type="hidden" class="btn btn-default" name="acao" value="inserirempresa">
        
	<input type="submit" class="btn btn-default" name="cadastrar" value="Cadastrar">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="../index.php"><button type="button" class="btn btn-default">Voltar</button></a>
    </div><br><br>
    </div>
    </form></div></div>
    <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
    <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
    <script language="JavaScript" type="text/javascript">
   function mascaraData(campoData){
              var data = campoData.value;
              if (data.length == 2){
                  data = data + '/';
                  document.forms[0].data.value = data;
      return true;              
              }
              if (data.length == 5){
                  data = data + '/';
                  document.forms[0].data.value = data;
                  return true;
              }
         }
        function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
}
</script>
<script type="text/javascript">
$(document).ready(function(){
	$("#cep").mask("99999-999");
     $('#rg').mask('99.999.999-9');
});
    </script>
</body>
</html>