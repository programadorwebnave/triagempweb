<!DOCTYPE html>
<?php session_start(); ?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HotelJob - Seu Proximo Emprego!</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/style.css" type="text/css" !important>
    <style>span{color: #f00}</style>
      <link rel="icon" href="img/logo-edit.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
<body class="cadastrar">
  <nav class="navbar navbar-default navbar-fixed-top menu">
      <div class="container-fluid">
          <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#barraBasica">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              </button>
                    <a class="navbar-brand" href="#"><img src="../img/hj2.png" class="img-responsive img_logo"></a>
          </div>
          <div class="collapse navbar-collapse menu_principal" id="barraBasica">
          <ul class="nav navbar-nav ul_lista">
              <li class="item_lista"><a href="../index.php" class="scroll" style="color:#fff">Home<span class="sr-only">(current)</span></a></li>
              <li class="item_lista"><a href="../index.php" style="color:#fff" class="scroll">Missão</a></li>
              <li class="item_lista"><a href="../index.php" class="scroll" style="color:#fff">Oportunidades</a></li>
              <li class="item_lista"><a style="color:#fff" href="#" data-toggle="modal" data-target="#login">Login</a></li>
              </ul>
              
          </div>
          </div>
      </nav>
    
          <div class="col-xs-12 col-sm-8 col-sm-push-2 col-md-12 col-md-push-0 moddal">
          

<div class="col-xs-10 col-xs-push-1">
<form class="form-group" action="../php/validacao/valida.php" method="POST" enctype="multipart/form-data" accept-charset="utf-8">

<br>
    <h1 class="modal-title">Insira seus dados</h1>
    <div class="line"> </div>
          <br>
<div class="modal-body">
    
    <div class="col-md-6">
<!-- [[[[[[     CAMPO NOME      ]]]]]]-->
	<label class="col-form-label">Nome</label>
	<input class="form-control" type="text" placeholder="Digite seu nome completo" name="nome"
<?php
    if(isset($_SESSION["v_nome"])){
        echo "value= '".$_SESSION["v_nome"]."'";
        unset($_SESSION["v_nome"]);
    }?>>
<?php 
    if (isset($_SESSION["nome_vazio"])){
        echo "<span>".$_SESSION["nome_vazio"]."</span>";
        unset($_SESSION["nome_vazio"]);
}?><br>
    
<!--[[[[[[[     CAMPO EMAIL     ]]]]]]]-->
    <label>E-mail</label>
	<input class="form-control" type="email" placeholder="Digite seu email" name="email" 
<?php
    if(isset($_SESSION["v_email"])){
        echo "value= '".$_SESSION["v_email"]."'";
        unset($_SESSION["v_email"]);
    }?>>
<?php 
    if (isset($_SESSION["email_vazio"])){
        echo "<span>".$_SESSION["email_vazio"]."</span>";
        unset($_SESSION["email_vazio"]);
}
        if(isset($_SESSION['email_ex'])){
            echo "<span>".$_SESSION['email_ex'].'</span><br>';
            unset($_SESSION['email_ex']);
}
        
        ?><br>
    
	<div class="form-group">
<!-- [[[[[[[        CAMPO DATA      ]]]]]]]-->
	<label for="formulario_idade">Data de Nascimento</label>
	<input class="form-control" type="text" name="data" placeholder="00/00/0000" OnKeyUp="mascaraData(this);" maxlength="10"
<?php
    if(isset($_SESSION["v_data"])){
        echo "value= '".$_SESSION["v_data"]."'";
        unset($_SESSION["v_data"]);
    }?>>
<?php 
    if (isset($_SESSION["data_vazio"])){
        echo "<span>".$_SESSION["data_vazio"]."</span>";
        unset($_SESSION["data_vazio"]);
}?>
	</div>

    <!-- [[[[[[     CAMPO CARGO      ]]]]]]-->
	<label for="cargo">Cargo</label>
	<select id="cargo" name="cargo" class="form-control">
		<option value="Garcon">Garçon</option>
		<option value="Steward">Steward</option>
		<option value="Cumin">Cumin</option>
		<option value="Camareira">Camareira</option>
		<option value="Chefe de Andar">Chefe de Andar</option>
		<option value="Governanta">Governanta</option>
		<option value="Recepcionista">Recepcionista</option>
		<option value="Mensageiro">Mensageiro</option>
		<option value="Auxiliar de Manutenção">Auxiliar de Manutenção</option>
		<option value="Eletricista">Eletricista</option>
		<option value="Bombeiro">Bombeiro</option>
		<option value="Marceneiro">Marceneiro</option>
		<option value="Rede e Telefonia">Rede e Telefonia</option>
		<option value="Pintor">Pintor</option>
		<option value="Pedreiro">Pedreiro</option>
	</select><br>

    
<!--[[[[[[[[        CAMPO SEXO      ]]]]]]]]-->
	<label for="sexo">Sexo</label>
	<select id="sexo" class="form-control" name="sexo">

		<option value="Masculino">Masculino</option>
		<option value="Feminino">Feminino</option>

</select><br>
       
    <!-- [[[[[[[        CAMPO ENDEREÇO        ]]]]]]]-->
	<label>Endereço</label>
	<input class="form-control" type="text" placeholder="Digite seu Endereço" name="endereco" 
<?php
    if(isset($_SESSION["v_endereco"])){
        echo "value= '".$_SESSION["v_endereco"]."'";
        unset($_SESSION["v_endereco"]);
    }?>>
<?php 
    if (isset($_SESSION["endereco_vazio"])){
        echo "<span>".$_SESSION["endereco_vazio"]."</span>";
        unset($_SESSION["endereco_vazio"]);
}?><br>
    
<!-- [[[[[[[        CAMPO CIDADE        ]]]]]]]-->
	<label for="formulario_cidade">Cidade</label>
	<input class="form-control" type="text" placeholder="Digite sua cidade" name="cidade" value="Rio de Janeiro"
<?php
    if(isset($_SESSION["v_cidade"])){
        echo "value= '".$_SESSION["v_cidade"]."'";
        unset($_SESSION["v_cidade"]);
    }?>>
<?php 
    if (isset($_SESSION["cidade_vazio"])){
        echo "<span>".$_SESSION["cidade_vazio"]."</span>";
        unset($_SESSION["cidade_vazio"]);
}?><br>
 
    
<!-- [[[[[[[        CAMPO Região       ]]]]]]]-->
	<label for="formulario_estado">Região</label>
<select name="regiao" class="form-control">
	<option value="Zona Norte">Zona Norte</option>
    <option value="Zona Sul">Zona Sul</option>
    <option value="Zona Leste">Zona Leste</option>
    <option value="Zona Oeste">Zona Oeste</option>
</select><br>
    </div>
    <div class="col-md-6">
<!-- [[[[[[[        CAMPO CEP        ]]]]]]]-->
	<label for="formulario_cep">CEP</label>
	<input class="form-control" id="cep" type="text" placeholder="Digite seu cep" name="cep" 
<?php
    if(isset($_SESSION["v_cep"])){
        echo "value= '".$_SESSION["v_cep"]."'";
        unset($_SESSION["v_cep"]);
    }?>>
<?php 
    if (isset($_SESSION["cep_vazio"])){
        echo "<span>".$_SESSION["cep_vazio"]."</span>";
        unset($_SESSION["cep_vazio"]);
}?><br>

<!-- [[[[[[[        CAMPO TELEFONE        ]]]]]]]-->
	<label for="formulario_telefone">Telefone</label>
     <input type="text" class="form-control" name="telefone" onkeyup="mascara( this, mtel );" maxlength="15" 
placeholder="(11) 11111-1111"
<?php
    if(isset($_SESSION["v_telefone"])){
        echo "value= '".$_SESSION["v_telefone"]."'";
        unset($_SESSION["v_telefone"]);
    }?>>
<?php 
    if (isset($_SESSION["telefone_vazio"])){
        echo "<span>".$_SESSION["telefone_vazio"]."</span>";
        unset($_SESSION["telefone_vazio"]);
}?><br>
    <!-- [[[[[[[        CAMPO RG        ]]]]]]]-->
	<label for="formulario_identidade">RG</label>
	<input class="form-control" type="text" name="rg" maxlength="9"
<?php
    if(isset($_SESSION["v_rg"])){
        echo "value= '".$_SESSION["v_rg"]."'";
        unset($_SESSION["v_rg"]);
    }?>>
<?php 
    if (isset($_SESSION["rg_vazio"])){
        echo "<span>".$_SESSION["rg_vazio"]."</span>";
        unset($_SESSION["rg_vazio"]);
}
    if(isset($_SESSION['rg_ex'])){
        echo "<span>".$_SESSION['rg_ex']."</span><br>";
        unset($_SESSION['rg_ex']);
    }
        ?>
    <br>

<!-- [[[[[[[        CAMPO CPF        ]]]]]]]-->
	<label for="formulario_cpf">CPF</label>
	<input class="form-control" type="text" placeholder="000.111.000-11" name="cpf" maxlength="11"
<?php
    if(isset($_SESSION["v_cpf"])){
        echo "value= '".$_SESSION["v_cpf"]."'";
        unset($_SESSION["v_cpf"]);
    }?>>
<?php 
    if (isset($_SESSION["cpf_vazio"])){
        echo "<span>".$_SESSION["cpf_vazio"]."</span>";
        unset($_SESSION["cpf_vazio"]);
}
    if (isset($_SESSION['cpf_ex'])){
        echo "<span>".$_SESSION['cpf_ex']."</span><br>";
        unset($_SESSION['cpf_ex']);
    }   
        ?> <br>
	<!--[[[[[[             Insira Curriculo            ]]]]]]--->
        <label>Inserir Curriculo</label>
        <input type="file" name="curriculo" class="form-group">
    
<!-- [[[[[[[        CAMPO Senha         ]]]]]]]-->
	<label for="formulario_eleitor">Senha</label>
	<input class="form-control" type="password" name="senha">
<?php 
    if (isset($_SESSION["senha_vazio"])){
        echo "<span>".$_SESSION["senha_vazio"]."</span>";
        unset($_SESSION["senha_vazio"]);
}if (isset($_SESSION["senha_erro"])){
        echo "<span>".$_SESSION["senha_erro"]."</span>";
        unset($_SESSION["senha_erro"]);
}?><br>
	

<!-- [[[[[[[        CAMPO Confirmar Senha        ]]]]]]]-->
	<label for="formulario_cart_trab">Confirmar Senha</label>
	<input class="form-control" type="password" name="c_senha">
<?php 
    if (isset($_SESSION["senha_vazio2"])){
        echo "<span>".$_SESSION["senha_vazio2"]."</span>";
        unset($_SESSION["senha_vazio2"]);}
    
    if (isset($_SESSION["senha_erro2"])){
        echo "<span>".$_SESSION["senha_erro2"]."</span>";
        unset($_SESSION["senha_erro2"]);
}?>
   
<br>    
    
    
        <input type="hidden" class="btn btn-default" name="acao" value="inserir">
        
	<input type="submit" class="btn btn-default" name="cadastrar" value="Cadastrar">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="../index.php"><button type="button" class="btn btn-default">Voltar</button></a>
    </div>
    
    
</div>
    
    </form>
   
    </div>
    </div>
     <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>    <script language="JavaScript" type="text/javascript">
   function mascaraData(campoData){
              var data = campoData.value;
              if (data.length == 2){
                  data = data + '/';
                  document.forms[0].data.value = data;
      return true;              
              }
              if (data.length == 5){
                  data = data + '/';
                  document.forms[0].data.value = data;
                  return true;
              }
         }
        function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
}
</script>
<script type="text/javascript">
$(document).ready(function(){
	$("#cep").mask("99999-999");
     $('#rg').mask('99.999.999-9');
});
</script>
              
</body>
</html>