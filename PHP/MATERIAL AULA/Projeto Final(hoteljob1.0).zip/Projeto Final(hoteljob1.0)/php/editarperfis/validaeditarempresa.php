<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Cadastrar</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/style.css" !important>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>span{color: #f00}</style>
</head>
    <body>
<?php
session_start();
include '../validacao/functions.php';
      if(isset($_SESSION['usuarioempresa'])){
          $emp = selectIDempresa($_SESSION['usuarioempresa']);
      }
$url = 'editarempresa.php';
$nome = $_POST["nome"];
$check = 0;
/* Campo Nome */
if(empty($nome) || is_numeric($nome)){
    $_SESSION["nome_vazio"] = "Campo Razão Social Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
if(isset($nome)){
    $_SESSION["v_nome"] = $_POST["nome"];
}
        /*Campo Nome Fachada */
if(empty($_POST['nome_fachada']) || is_numeric($_POST['nome_fachada'])){
    $_SESSION["nomef_vazio"] = "Campo Nome de Fachada Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
if(isset($_POST['nome_fachada'])){
    $_SESSION["v_nomef"] = $_POST["nome_fachada"];
}
        

   
        
        /*Campo Endereco*/
if(empty($_POST['endereco'])){
    $_SESSION["endereco_vazio"] = "Campo Cargo não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_endereco"] = $_POST['endereco'];
}
        

        
        /*Campo Cidade */
if(empty($_POST['cidade'])){
    $_SESSION["cidade_vazio"] = "Campo Endereço não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_cidade"] = $_POST['cidade'];
}
        /* Campo Cep */
        
if(empty($_POST['cep'])) {
    $_SESSION["cep_vazio"] = "Campo CEP Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_cep"] = $_POST['cep'];
}
        
        /*Campo Telefone*/
        
if(empty($_POST['telefone'])){
    $_SESSION["telefone_vazio"] = "Campo Telefone não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_telefone"] = $_POST['telefone'];
}
        
        /*campo senha*/
if(empty($_POST['senha'])||empty($_POST['c_senha'])){
    $_SESSION["senha_vazio"] = "Campo Senha não preenchido<br>";
    $_SESSION["senha_vazio2"] = "Campo Senha não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else if($_POST['senha'] != $_POST['c_senha']){
    $_SESSION["senha_erro"] = "As senhas não correspondem<br>";
    $_SESSION["senha_erro2"] = "As senhas não correspondem<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}

function alterarempresa (){
    $razaosocial = $_POST['nome']; $nomefachada = $_POST['nome_fachada']; $endereco = $_POST['endereco']; $cidade = $_POST['cidade']; $regiao= $_POST['regiao']; $cep = $_POST['cep']; $telefone = $_POST['telefone']; $senha = $_POST['senha']; $id = $_SESSION['usuarioempresa'];
    $conn = conect();
    $sql = "UPDATE empresas SET razaosocial = '$razaosocial', nomefachada = '$nomefachada', endereco = '$endereco', cidade = '$cidade', regiao = '$regiao', cep = '$cep', telefone = '$telefone', senha = '$senha' WHERE id = '$id';";
    $push = mysqli_query($conn, $sql);
    if ($push){
  echo "<div class='alert alert-success' role='alert'>As Informações foram alteradas corretamente!</div>";
        echo "<meta http-equiv='refresh' content='3;URL=../paginainicialempresa.php'>";    }
}
        
if(isset($_POST['acao'])){
    if($check == 0 && $_POST['acao'] == 'alterarempresa'){
        alterarempresa();
    }
}
        
        
        
        
        
        
        
        
?>
        </body>
</html>
    
