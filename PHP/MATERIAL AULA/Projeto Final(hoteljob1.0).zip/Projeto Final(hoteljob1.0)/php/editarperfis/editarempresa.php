<!DOCTYPE html>
<?php
session_start();
include "../validacao/functions.php";
      if(isset($_SESSION['usuarioempresa'])){
          $emp = selectIDempresa($_SESSION['usuarioempresa']);
      }
?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagina Incial - HotelJob</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="../../css/styles.css" type="text/css" !important>
        <script src="../../js/responsive-nav.js"></script>
      <style>span{color: #f00}</style>
      <link rel="icon" href="../img/logo-edit.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="body">
        <!-- INICIO DO MENU DE NAVEGAÇÃO -->

      <div role="navigation" id="foo" class="nav-collapse">
        <li><h2  style="color: #fff"><?=$emp['nomefachada']?></h2></li>
      <ul>
         
        <li><a href="../paginainicialempresa.php" style="color: #fff">Banco de Funcionarios</a></li>
        <li><a href="editarperfis/editarempresa.php" style="color: #fff">Editar Perfil</a></li>
        <li><a href="../adicionarvaga.php" style="color: #fff">Adicionar Vagas</a></li>
        <li> <a href="../gerenciarvagas.php" style="color: #fff">Gerenciar Vagas</a></li>
        <li><a href="../vercandidatos.php" style="color: #fff">Ver Candidatos</a></li>
        <li><a href="../validacao/sair.php" style="color: #fff">Sair</a></li>
          </ul>
    </div>

    <div role="main" class="main">
      <a href="#nav" class="nav-toggle">Menu</a>
        
        
         <div class="container-fluid">
      <div class="logo_banco col-md-5">
        <img src="../../img/logo-edit.png" class="img-responsive">
        </div>
      <div class="row">
          <div class="col-xs-10 col-md-5 titulovagas">
          <h1>Alterar Cadastro</h1><hr>
              <h3>Atenção! Alguns campos não podem ser modificados.
              </h3> </div>
             </div>
             
             
             
<form class="form-group" action="validaeditarempresa.php" method="POST" enctype="multipart/form-data" accept-charset="utf-8">

<div class="modal-body">
    
    <div class="col-md-6">
<!-- [[[[[[     CAMPO NOME      ]]]]]]-->
	<label class="col-form-label">Razão Social</label>
	<input class="form-control" type="text" placeholder="Nome Completo da Empresa" name="nome" value="<?=$emp['razaosocial']?>"
<?php
    if(isset($_SESSION["v_nome"])){
        echo "value= '".$_SESSION["v_nome"]."'";
        unset($_SESSION["v_nome"]);
    }?>>
<?php 
    if (isset($_SESSION["nome_vazio"])){
        echo "<span>".$_SESSION["nome_vazio"]."</span>";
        unset($_SESSION["nome_vazio"]);
}?><br>

<!--[[[[[[      CAMPO NOME DE FACHADA       ]]]]]]-->
<label>Nome de Fachada</label>
<input type="text" name="nome_fachada" placeholder="Nome Publicitario da Empresa" class="form-control" value="<?=$emp['nomefachada']?>" <?php
    if(isset($_SESSION["v_nomef"])){
        echo "value= '".$_SESSION["v_nomef"]."'";
        unset($_SESSION["v_nomef"]);
    }?>>
        
        <?php 
    if (isset($_SESSION["nomef_vazio"])){
        echo "<span>".$_SESSION["nomef_vazio"]."</span>";
        unset($_SESSION["nomef_vazio"]);
}?><br>
        
        
        
<!-- [[[[[[[        CAMPO CNPJ      ]]]]]]]-->
<label>CNPJ</label>
<input type="text" name="cnpj" class="form-control" placeholder="Digite o CNPJ da Empresa" maxlength="14" disabled value="<?=$emp['cnpj']?>"<?php
    if(isset($_SESSION["v_cnpj"])){
        echo "value= '".$_SESSION["v_cnpj"]."'";
        unset($_SESSION["v_cnpj"]);
    }?>>
        
        
        
        <br>
<!--[[[[[[[     CAMPO EMAIL     ]]]]]]]-->
    <label>E-mail</label>
	<input class="form-control" type="email" placeholder="Digite o Email da Empresa" name="email" disabled value="<?=$emp['email']?>"
<?php
    if(isset($_SESSION["v_email"])){
        echo "value= '".$_SESSION["v_email"]."'";
        unset($_SESSION["v_email"]);
    }?>>
<?php 
    if (isset($_SESSION["email_vazio"])){
        echo "<span>".$_SESSION["email_vazio"]."</span>";
        unset($_SESSION["email_vazio"]);
}
        if(isset($_SESSION['email_ex'])){
            echo "<span>".$_SESSION['email_ex'].'</span><br>';
            unset($_SESSION['email_ex']);
}
        
        ?>
    
	

    <br>
       
    <!-- [[[[[[[        CAMPO ENDEREÇO        ]]]]]]]-->
	<label>Endereço</label>
	<input class="form-control" type="text" placeholder="Digite seu Endereço" name="endereco" value="<?=$emp['endereco']?>"
<?php
    if(isset($_SESSION["v_endereco"])){
        echo "value= '".$_SESSION["v_endereco"]."'";
        unset($_SESSION["v_endereco"]);
    }?>>
<?php 
    if (isset($_SESSION["endereco_vazio"])){
        echo "<span>".$_SESSION["endereco_vazio"]."</span>";
        unset($_SESSION["endereco_vazio"]);
}?><br>
    
<!-- [[[[[[[        CAMPO CIDADE        ]]]]]]]-->
	<label for="formulario_cidade">Cidade</label>
	<input class="form-control" type="text" placeholder="Digite sua cidade" name="cidade" value="<?=$emp['cidade']?>"
<?php
    if(isset($_SESSION["v_cidade"])){
        echo "value= '".$_SESSION["v_cidade"]."'";
        unset($_SESSION["v_cidade"]);
    }?>>
<?php 
    if (isset($_SESSION["cidade_vazio"])){
        echo "<span>".$_SESSION["cidade_vazio"]."</span>";
        unset($_SESSION["cidade_vazio"]);
}?><br>
 </div>
    <div class="col-md-6">
    
<!-- [[[[[[[        CAMPO Regiao        ]]]]]]]-->
	<label for="formulario_estado">Região</label>
<select name="regiao" class="form-control">
	<option value="Zona Norte">Zona Norte</option>
    <option value="Zona Sul">Zona Sul</option>
    <option value="Zona Leste">Zona Leste</option>
    <option value="Zona Oeste">Zona Oeste</option>
</select><br>
    
<!-- [[[[[[[        CAMPO CEP        ]]]]]]]-->
	<label for="formulario_cep">CEP</label>
	<input class="form-control" id="cep" type="text" placeholder="Digite seu cep" name="cep" value="<?=$emp['cep']?>"
<?php
    if(isset($_SESSION["v_cep"])){
        echo "value= '".$_SESSION["v_cep"]."'";
        unset($_SESSION["v_cep"]);
    }?>>
<?php 
    if (isset($_SESSION["cep_vazio"])){
        echo "<span>".$_SESSION["cep_vazio"]."</span>";
        unset($_SESSION["cep_vazio"]);
}?><br>

<!-- [[[[[[[        CAMPO TELEFONE        ]]]]]]]-->
	<label for="formulario_telefone">Telefone</label>
     <input type="text" class="form-control" name="telefone" onkeyup="mascara( this, mtel );" maxlength="15" value="<?=$emp['telefone']?>"
placeholder="(11) 11111-1111"
<?php
    if(isset($_SESSION["v_telefone"])){
        echo "value= '".$_SESSION["v_telefone"]."'";
        unset($_SESSION["v_telefone"]);
    }?>>
<?php 
    if (isset($_SESSION["telefone_vazio"])){
        echo "<span>".$_SESSION["telefone_vazio"]."</span>";
        unset($_SESSION["telefone_vazio"]);
}?><br>
    
<!-- [[[[[[[        CAMPO Senha         ]]]]]]]-->
	<label for="formulario_eleitor">Senha</label>
	<input class="form-control" type="password" name="senha">
<?php 
    if (isset($_SESSION["senha_vazio"])){
        echo "<span>".$_SESSION["senha_vazio"]."</span>";
        unset($_SESSION["senha_vazio"]);
}if (isset($_SESSION["senha_erro"])){
        echo "<span>".$_SESSION["senha_erro"]."</span>";
        unset($_SESSION["senha_erro"]);
}?><br>
	

<!-- [[[[[[[        CAMPO Confirmar Senha        ]]]]]]]-->
	<label for="formulario_cart_trab">Confirmar Senha</label>
	<input class="form-control" type="password" name="c_senha">
<?php 
    if (isset($_SESSION["senha_vazio2"])){
        echo "<span>".$_SESSION["senha_vazio2"]."</span>";
        unset($_SESSION["senha_vazio2"]);}
    
    if (isset($_SESSION["senha_erro2"])){
        echo "<span>".$_SESSION["senha_erro2"]."</span>";
        unset($_SESSION["senha_erro2"]);
}?>
   
<br>    
    <input type="hidden" class="btn btn-default" name="acao" value="alterarempresa">
        
	<input type="submit" class="btn btn-default" name="cadastrar" value="Cadastrar">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="../index.php"><button type="button" class="btn btn-default">Voltar</button></a>
    </div><br><br>
    </div>
    </form>
             
             
             
             
       
        <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
        
        
        
      </div>
      </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script type="text/javascript">
	  
  $(document).ready(function() {
        
	/*Menu-toggle*/
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("active");
    });

    /*Scroll Spy*/
    $('body').scrollspy({ target: '#spy', offset:80});

    /*Smooth link animation*/
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
        
        });
      </script>
       <script>
      var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
    </script>
</html>
      