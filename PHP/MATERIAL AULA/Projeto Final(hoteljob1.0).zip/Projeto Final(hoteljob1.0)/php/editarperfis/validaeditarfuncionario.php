<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Cadastrar</title>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width,initial-scale=1"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/style.css" !important>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>span{color: #f00}</style>
</head>
<?php
session_start();
    include '../validacao/functions.php';

    if(isset($_SESSION['usuariofuncionario'])){
    $fun = selectfuncionarioid($_SESSION['usuariofuncionario']);
    $l = selectID($fun['id']);
}

else{
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
}
$url = 'editarfuncionario.php';
$nome = $_POST["nome"]; $data = $_POST["data"];$cargo = $_POST["cargo"];$sexo = $_POST["sexo"];$endereco = $_POST["endereco"];$cidade = $_POST["cidade"];$regiao = $_POST["regiao"];$cep = $_POST["cep"];$telefone = $_POST["telefone"]; $senha = $_POST["senha"];$c_senha = $_POST["c_senha"];
$check = 0;
    
if(empty($nome) || is_numeric($nome)){
    $_SESSION["nome_vazio"] = "Campo nome Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
if(isset($nome)){
    $_SESSION["v_nome"] = $_POST["nome"];
}

if(empty($data) || strlen($data) < 10){
    $_SESSION["data_vazio"] = "Campo data Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_data"] = $data;
}
if(empty($endereco)){
    $_SESSION["endereco_vazio"] = "Campo Cargo não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_endereco"] = $endereco;
}
if(empty($cidade)){
    $_SESSION["cidade_vazio"] = "Campo Endereço não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_cidade"] = $cidade;
}
if(empty($cep)) {
    $_SESSION["cep_vazio"] = "Campo CEP Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_cep"] = $cep;
}
if(empty($telefone)){
    $_SESSION["telefone_vazio"] = "Campo Telefone não preenchido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else{
    $_SESSION["v_telefone"] = $telefone;
}



if(empty($senha) || strlen($senha) < 6 ||empty($c_senha)){
    $_SESSION["senha_vazio"] = "Campo Senha Está Inválido<br>";
    $_SESSION["senha_vazio2"] = "Campo Senha Está Inválido<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}
else if($senha != $c_senha){
    $_SESSION["senha_erro"] = "As senhas não correspondem<br>";
    $_SESSION["senha_erro2"] = "As senhas não correspondem<br>";
    echo"<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=$url'>";
    $check++;
}

function updatefuncionario(){
    $conn = conect();
    $nome = $_POST["nome"]; $data = $_POST["data"];$cargo = $_POST["cargo"];$sexo = $_POST["sexo"];$endereco = $_POST["endereco"];$cidade = $_POST["cidade"];$regiao = $_POST["regiao"];$cep = $_POST["cep"];$telefone = $_POST["telefone"]; $senha = $_POST["senha"]; $id = $_SESSION['usuariofuncionario'];
    $sql = "UPDATE funcionarios SET nome = '$nome', data = '$data', cargo = '$cargo', sexo = '$sexo', endereco = '$endereco', cidade = '$cidade', regiao = '$regiao', cep = '$cep', telefone = '$telefone', senha = '$senha' WHERE id = '$id';";
    $push = mysqli_query($conn, $sql);
    if ($push){
        echo "<div class='alert alert-success' role='alert'>As Informações foram alteradas corretamente!</div>";
        echo "<meta http-equiv='refresh' content='3;URL=../paginainicial.php'>";
    }
}
$acao = $_POST['acao'];
    
if ($check == 0 && $acao == "inserir"){
    updatefuncionario();
}
    
    
    
    
    
    
    
    
    
    
    
    
    
  