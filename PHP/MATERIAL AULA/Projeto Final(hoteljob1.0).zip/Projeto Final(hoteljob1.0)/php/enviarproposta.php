<!DOCTYPE html>
<?php
session_start();
include "validacao/functions.php";
      if(isset($_SESSION['usuarioempresa'])){
          $emp = selectIDempresa($_SESSION['usuarioempresa']);
      }
?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pagina Incial - HotelJob</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="../css/styles.css" type="text/css" !important>
        <script src="../js/responsive-nav.js"></script>
      <style>span{color: #000}</style>
      <link rel="icon" href="../img/logo-edit.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
        <!-- INICIO DO MENU DE NAVEGAÇÃO -->

      <div role="navigation" id="foo" class="nav-collapse">
        <li><h2  style="color: #fff"><?=$emp['nomefachada']?></h2></li>
      <ul>
         
        <li><a href="paginainicialempresa.php" style="color: #fff">Banco de Funcionarios</a></li>
        <li><a href="editarperfis/editarempresa.php" style="color: #fff">Editar Perfil</a></li>
        <li><a href="adicionarvaga.php" style="color: #fff">Adicionar Vagas</a></li>
        <li> <a href="gerenciarvagas.php" style="color: #fff">Gerenciar Vagas</a></li>
        <li><a href="vercandidatos.php" style="color: #fff">Ver Candidatos</a></li>
        <li><a href="validacao/sair.php" style="color: #fff">Sair</a></li>
          </ul>
    </div>
<?php
    $grupo = selectID($_POST['id']);
    ?>
      
     
      
      
    <div role="main" class="main">
      <a href="#nav" class="nav-toggle">Menu</a>
        
         
         <div class="container-fluid">
      <div class="logo_banco col-md-5">
        <img src="../img/logo-edit.png" class="img-responsive">
        </div>
      <div class="row">
          <div class="col-xs-10 col-md-5 titulovagas">
          <h1>Enviar Proposta Para: </h1><hr>
              <h2> <?=$grupo['nome']?></h2>
          </div>
             </div>
<br>
        
        
      <div class="container-fluid">
          <div class="row">
                
             <form method="post" action="validacao/functions.php">
                 <div class="col-xs-10 col-xs-push-1 col-sm-8 col-sm-push-2 col-md-6 col-md-push-0 col-lg-5 col-lg-push-1">
                <div class="form-group">
                 <label for="nome">Titulo da Vaga</label>
                    <input type="text" class="form-control" name="titulo_vaga" placeholder="Digite seu nome">
                 </div>
                     </div>
                 <div class="col-xs-10 col-xs-push-1 col-sm-8 col-sm-push-2 col-md-6 col-md-push-0 col-lg-5 col-lg-push-1">
	           <label for="cargo">Cargo</label>
	           <select id="cargo" name="cargo" class="form-control">
		      <option value="Garcon">Garçon</option>
		      <option value="Steward">Steward</option>
		      <option value="Cumin">Cumin</option>
		      <option value="Camareira">Camareira</option>
              <option value="Chefe de Andar">Chefe de Andar</option>
		      <option value="Governanta">Governanta</option>
		      <option value="Recepcionista">Recepcionista</option>
		      <option value="Mensageiro">Mensageiro</option>
              <option value="Auxiliar de Manutenção">Auxiliar de Manutenção</option>
		      <option value="Eletricista">Eletricista</option>
		      <option value="Bombeiro">Bombeiro</option>
		      <option value="Marceneiro">Marceneiro</option>
		      <option value="Rede e Telefonia">Rede e Telefonia</option>
              <option value="Pintor">Pintor</option>
		      <option value="Pedreiro">Pedreiro</option>
	</select><br>
                 </div>
                     <div class="col-xs-10 col-xs-push-1 col-sm-8 col-sm-push-2 col-md-6 col-md-push-0 col-lg-5 col-lg-push-1">
                 <div class="form-group">
                 <label for="email">Descrição da Vaga</label>
                    <input type="text" class="form-control" name="descricao" placeholder="Dê detalhes sobre a vaga">
                 </div>
                 </div>
                 <div class="col-xs-10 col-xs-push-1 col-sm-8 col-sm-push-2 col-md-6 col-md-push-0 col-lg-5 col-lg-push-1">
                 <div class="form-group">
                 <label for="endereco">Experiência</label>
                    <select name="experiencia" class="form-control ">
                     <option value="semexperiencia" class="form-control">Sem Experiência</option>
                        <option value="comexperiencia">Com Experiência</option>
                     </select>
                 </div>
                 </div>
                 <div class="col-xs-10 col-xs-push-1 col-sm-8 col-sm-push-2 col-md-6 col-md-push-0 col-lg-5 col-lg-push-1">
                 <div class="form-group">
                 <label for="senha">Salário</label>
                    <input type="text" class="form-control" id="senha" name="salario" placeholder="Digite o salário">
                 </div>
                     
                 </div>
                 <div class="col-xs-10 col-xs-push-1 col-sm-8 col-sm-push-2 col-md-6 col-md-push-0 col-lg-5 col-lg-push-1">
                     <div class="form-group">
                     <label>Instruções para o candidato</label>
                         <input type="text" name="intrucoes" class="form-control" placeholder="Informações de horario, local para entrevistas, etc">
                     </div>
    <input type="hidden" name="id" value="<?=$emp['id']?>">
                 <input type="hidden" name="acao" value="enviarproposta">
                     <input type="hidden" name="idfuncionario" value="<?=$grupo['cpf']?>">
                     <input type="hidden" name="idempresa" value="<?=$emp['id']?>">
                 <input type="submit" class="form-control" style="background: rgb(183,132,9); color:#fff" value="Enviar Proposta">
                 </div>
                </form>
        </div>
              </div><!-- Fim do corpo do modal e inicio do rodapé. Apenas com botões de cadastrar e fechar -->
      </div><br><br><br><br>
        
         <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
          </div>
        
        
        
        
        
        
        
      
      
      </body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  <script type="text/javascript">
	  
  $(document).ready(function() {
        
	/*Menu-toggle*/
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("active");
    });

    /*Scroll Spy*/
    $('body').scrollspy({ target: '#spy', offset:80});

    /*Smooth link animation*/
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') || location.hostname == this.hostname) {

            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 1000);
                return false;
            }
        }
    });
        
        });
      </script>
       <script>
      var navigation = responsiveNav("foo", {customToggle: ".nav-toggle"});
    </script>
</html>
        