<!DOCTYPE html>
<?php
session_start();
if (isset($_SESSION['usuariofuncionario'])){
    echo "<meta http-equiv='refresh' content='0;URL=php/paginainicial.php'>";
}
if (isset($_SESSION['usuarioempresa'])){
    echo "<meta http-equiv='refresh' content='0;URL=php/paginainicialempresa.php'>";
}
?>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HotelJob - Seu Proximo Emprego!</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz" rel="stylesheet"> 
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="css/style.css" type="text/css" !important>
    
      <link rel="icon" href="img/logo10.png">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body id="home" class="body">
      <!-- INICIO DO MENU DE NAVEGAÇÃO -->
    <nav class="navbar navbar-default navbar-fixed-top menu">
      <div class="container-fluid">
          <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#barraBasica">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              </button>
                    <a class="navbar-brand" href="#"><img src="img/logo-edit.png" class="img-responsive img_logo"></a>
          </div>
          <div class="collapse navbar-collapse menu_principal" id="barraBasica">
          <ul class="nav navbar-nav ul_lista">
              <li class="item_lista"><a href="#home" class="scroll" style="color:#fff">Home<span class="sr-only">(current)</span></a></li>
              <li class="item_lista"><a href="#missao" style="color:#fff" class="scroll">Missão</a></li>
              <li class="item_lista"><a href="#oport" class="scroll" style="color:#fff">Oportunidades</a></li>
              <li class="item_lista"><a style="color:#fff" href="#" data-toggle="modal" data-target="#login">Login</a></li>
              </ul>
              
          </div>
          </div>
      </nav>

      <div class="all">
      
      
      <!-- FIM DO MENU E INICIO DO MODAL DE LOGIN -->
      <div class="modal fade" id="login" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content moddal">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">x</button>
              <h4><span class="titulo">LOGIN</span></h4> 
          </div>
          <div class="modal-body">
            <form method="post" action="php/validacao/login.php">
              <div class="form-group">
                <label for="psw"><span class="glyphicon"></span> E-mail</label>
                <input type="email" name="email" class="form-control" id="psw" placeholder="nome@provedor.com" required autofocus="">
              </div>      

              <div class="form-group">
                <label for="usrname"><span class="glyphicon"></span> Senha</label>
                <input type="password" name="senha" class="form-control" id="Nome" required autofocus>
              </div>
                <div class="form-group">
                <label>Sou...</label>
                    <select name="sou" class="form-control">
                    <option value="funcionario">Funcionario</option>
                        <option value="empresa">Empresa</option>
                    </select>
                </div>
                
              <button type="submit" class="botao btn btn-block"> Entrar
                <span class="glyphicon glyphicon-ok"></span>
              </button>
                
              </form>
            </div>
            <div class="modal-footer">
              <button class="btn btn-danger btn-default pull-left" data-dismiss="modal">
                <span class="glyphicon glyphicon-remove"></span> Cancelar
              </button>
              <a href="php/pgcadastro.php"><button type="button" class="btn btn-default navbar-btn pull-right col-xs-push-12">Inscreva-se</button></a>             
        </div>  
      </div>
  </div>
</div>


          
<section class="banner">
	<div class="container-fluid">
		<div class="row">
			<div id="slideshow" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
    				<li data-target="#slideshow" data-slide-to="0" class="active"></li>
    				<li data-target="#slideshow" data-slide-to="1"></li>
  				</ol>	
  				<div class="carousel-inner">
  					<div class="item active">
  						<img src="img/1.png" style=" width: 100%; height: auto;">
  					</div>
  					<div class="item">
  						<img src="img/2.png" style=" width: 100%; height: auto;">
  					</div>
  				</div>
  				<a class="left carousel-control" href="#slideshow" data-slide="prev">
    				<span class="glyphicon glyphicon-chevron-left"></span>
    				<span class="sr-only">Voltar</span>
  				</a>
  				<a class="right carousel-control" href="#slideshow" data-slide="next">
    				<span class="glyphicon glyphicon-chevron-right"></span>
    				<span class="sr-only">Avançar</span>
  				</a>
			</div>
		</div>
	</div>	<span id="missao"></span>
</section>
      
      <!-- CAMPO MISSÃO -->
          

      <!-- CAMPO OPORTUNIDADES -->
<section class="oportunidades">
<div class="container-fluid">
    <div class="row">
        <h1>Áreas em Destaque</h1><hr>
    <div class="col-xs-pull-12 box_oport1">
				<div class="col-xs-10 col-xs-push-1 img_oport">
            		<img class="img-responsive" src="img/camareira.jpg">
            	</div>
                <div class="col-xs-12 box_oport_title">
            		<h1>Camareira</h1>
                	<h4>Pensando mais a longo prazo, a mobilidade dos capitais internacionais maximiza as possibilidades por conta do sistema de formação de quadros que corresponde às necessidades.Todavia, o acompanhamento das preferências de consumo aponta para a nada.</h4>
                </div>
			</div>
			<div class="col-xs-pull-12 box_oport2">
        		<div class="col-xs-10 col-xs-push-1 img_oport">
            		<img class="img-responsive" src="img/Recepcionista.jpg">
            	</div>
            	<div class="col-xs-12 box_oport_title">
            		<h1>Recepcionista</h1>
                	<h4>A certificação de metodologias que nos auxiliam a lidar com a determinação clara de objetivos facilita a criação das regras de conduta normativas.A certificação de metodologias que nos auxiliam a lidar com a determinação clara de objetivos.</h4>
            	</div>
        	</div>
        	<div class="col-xs-pull-12 box_oport3">
        		<div class="col-xs-10 col-xs-push-1 img_oport">
            		<img class="img-responsive" src="img/chef.jpg">
            	</div>
            	<div class="col-xs-12 box_oport_title">
            		<h1>Chef</h1>
                	<h4>A certificação de metodologias que nos auxiliam a lidar com a determinação clara de objetivos facilita a criação das regras de conduta normativas.Gostaria de enfatizar que a expansão dos mercados mundiais desafia a capacidade de equalização.</h4>
            	</div>
        	</div>
            <div class="row">
                
                <div class="col-xs-pull-12 box_oport1">
                    <div class="col-xs-10 col-xs-push-1">
                        <div class="col-xs-12 box_oport_title"><h3></h3></div>
                        <a href="php/cadastroempresa.php"><button type="button" class="btn btn-primary botao_banner">Quero Contratar</button></a><hr>
                    </div>
                </div>
            
                <div class="col-xs-pull-12 box_oport2">
                    <div class="col-xs-10 col-xs-push-1">
                    <div class="col-xs-12 box_oport_title"><h1>Cadastre-se e Faça Parte da HotelJob!</h1></div>
                    
                    </div>
                </div>

                <div class="col-xs-pull-12 box_oport3">
                    <div class="col-xs-10 col-xs-push-1">
                        <div class="col-xs-12 box_oport_title"><h3></h3></div>
                        <a href="php/pgcadastro.php" style="background:#fff"><button type="button" class="btn btn-primary botao_banner">Quero Trabalhar</button></a><hr>
                    </div>
                </div>

            </div>
		</div>
	</div>
</section>
          
          <section class="missao" >
<div class="container-fluid">
    <div class="row">
    <div class="col-xs-12">
        <h1>A Nossa Missao</h1><hr>
        <h3>A HotelJob oferece de maneira ágil e dinâmica serviços de garçons e garçonetes,
        bartenders, seguranças e demais profissionais da área de eventos. Nossa missão é garantir
         a nossos clientes e amigos o que há de melhor na qualidade e prestação de serviços hoteleiros 
        através de profissionais altamente qualificados e treinados
        </h3>
        <div class="col-xs-12 col-sm-8 col-sm-push-2 col-md-4 col-md-push-0 bx_missao">
        <h2>Responsabilidade</h2>
            <i class="fa fa-clock-o fa-5x" aria-hidden="true"></i>
            <h4>É importante questionar o quanto a consulta aos diversos militantes exige a precisão e a definição das diretrizes de desenvolvimento para o futuro.</h4>
        </div>
         <div class="col-xs-12 col-sm-8 col-sm-push-2 col-md-4  col-md-push-0 bx_missao">
        <h2>Profissionalismo</h2>
              <i class="fa fa-graduation-cap fa-5x" aria-hidden="true"></i>
            <h4>A prática cotidiana prova que a revolução dos costumes cumpre um papel essencial na formulação das diretrizes de desenvolvimento para o futuro. </h4>
        </div>
        <div class="col-xs-12 col-sm-8 col-sm-push-2 col-md-4 col-md-push-0 bx_missao">
        <h2>Compromisso</h2>
            <i class="fa fa-check-square-o fa-5x" aria-hidden="true"></i>

            <h4>No entanto, não podemos esquecer que o novo modelo estrutural aqui preconizado desafia a capacidade de equalização dos métodos utilizados na avaliação de resultados. </h4>
        </div>
        </div>
    </div><span id="oport"></span>
    </div>
      </section>
          <!-- [[[[[[[[[[[              PARCEIROS           ]]]]]]]]]]] -->
          <section class="oportunidades">
<div class="container-fluid">
    <div class="row">
        <h1>Parceiros</h1><hr>
    <div class="col-xs-12 box_oport1">
        <div>
        <div class="col-xs-10 col-xs-push-1 img_oport">
            <img class="img-responsive" src="img/sofitel2.jpg">
            </div>
            <div class="col-xs-12 box_oport_title">
            </div>
        </div>
        </div>
        <div class="col-xs-12 box_oport2">
        <div>
        <div class="col-xs-10 col-xs-push-1 img_oport">
            <img class="img-responsive" src="img/fasano2.jpg">
            </div>
            <div class="col-xs-12 box_oport_title">
            </div>
        </div>
        </div>
        <div class="col-xs-12 box_oport3">
        <div>
        <div class="col-xs-10 col-xs-push-1 img_oport">
            <img class="img-responsive" src="img/emiliano.jpg">
            </div>
            <div class="col-xs-12 box_oport_title">
            </div>
        </div>
        </div>
        <div class="col-xs-4 col-xs-push-4">
        </div>
         </div>
         
    
    </div>
              <br>
</section>
          <section>
          <div class="container-fluid">
              <div class="row">
              <div class="col-xs-12 rodape">
                  <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i>
                  <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                  <h3>HotelJob © 2017 - Todos os Direitos Reservados</h3>
                  
                  </div>
              </div>
              </div>
          
          </section>
    
      
      
      </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
      <script type="text/javascript" lang="js">
jQuery(document).ready(function($) { 
    $(".scroll").click(function(event){        
        event.preventDefault();
        $('html,body').animate({scrollTop:$(this.hash).offset().top}, 600);
   });
});
</script>
  </body>
</html>