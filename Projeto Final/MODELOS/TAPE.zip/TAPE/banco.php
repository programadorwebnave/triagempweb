<?php 
$con = mysqli_connect("sql310.epizy.com","epiz_21773436","acciostore","epiz_21773436_tape");
?>